# PDF visual and metadata verification - SCI-FRUIT v0.1/r0.2

Date: 2026-09-07. Scope: final documents only. All three PDFs reopened successfully and all **44 pages** were rendered with Poppler at 100 dpi and visually inspected by the root author. No clipping, overlap, malformed equations, missing/broken glyphs, unreadable tables, stray blank pages or orphan trailing paragraphs remain.

Scientific body type is 11 point. ECS index tables use 10 point; cover digest lines use smaller monospaced type with explicit break opportunities. The core has 22 pages to retain all complete requirements and predictions without shrinking scientific text; the soft approximate 16--20-page target was exceeded by two pages. Rationale is nine pages; ECS is thirteen pages. They are distinct reading surfaces, not reordered copies.

The final punctuation-only shared citation repair was rebuilt and rendered. Core pages 2--22 exactly matched the already inspected page PNG bytes; the changed cover was reinspected. Every final rationale and ECS page was reinspected. [PAGE_INSPECTION.json](PAGE_INSPECTION.json) binds each final PDF, every inspected page number and every final rendered page digest.

| PDF | Metadata title | Pages |
| --- | --- | ---: |
| [Core](../pdf/core.pdf) | SCI-FRUIT-NORMATIVE-CORE v0.1/r0.2 | 22 |
| [Rationale](../pdf/rationale.pdf) | SCI-FRUIT-SCIENTIFIC-RATIONALE v0.1/r0.2 | 9 |
| [ECS](../pdf/ecs.pdf) | SCI-FRUIT-ENGINEERING-CONFORMANCE v0.1/r0.2 | 13 |

All metadata authors are Grant Wilson; subjects state owner-review draft and numerical unavailability; creation dates are 2026-09-07 under the fixed source date. Every cover has owner, distinct identity/revision/status, date, exact Stage A archive, directive and approval digests, identical normative-core identity/digest, its own document-source identity/digest and build-record identity. These are source/control digest scopes, not a PDF hashing itself. Internal PDF destinations resolve within their documents. [Document checks](DOCUMENT_CHECKS.json) retain exact final metadata and PDF identities.

Rendering and clean compilation do not establish numerical conformance, response/covariance fidelity, coverage, qualification, validation, readiness or production authorization.
