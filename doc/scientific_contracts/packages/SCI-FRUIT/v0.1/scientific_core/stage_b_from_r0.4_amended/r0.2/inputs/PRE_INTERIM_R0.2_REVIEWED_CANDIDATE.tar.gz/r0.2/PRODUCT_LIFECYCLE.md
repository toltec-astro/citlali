# Product roles and ordered lifecycle

Sole normative authority: SCI-FRUIT-NORMATIVE-CORE v0.1/r0.2; canonical source-inventory SHA-256 `b02cff80eb4f1fb991214eb16d05a903f5dd3a363fe13461e83e5c96cf7411ed`. This is a derived navigation/evidence record, not independent science.

Canonical location: [Products, State and Completion sections](src/common/definitions.tex); REQ-017--022.

| Stable product role | Meaning |
| --- | --- |
| `SCI-FRUIT/ITERATION-RESULT` | Declared result, separately from its bundle. |
| `SCI-FRUIT/ITERATION-BUNDLE` | All universal and method-required roles and bindings. |
| `SCI-FRUIT/SUCCESSOR-STATE` | Produced causal successor; sufficiency is a distinct claim. |
| `SCI-FRUIT/CONTINUATION-STATE` | All future-consequential state queries/reconstruction and sufficiency status. |
| `SCI-FRUIT/PATH-SUPPORT` | Eight separately addressable support/influence roles. |
| `SCI-FRUIT/INFORMATION-ORIGIN` | Occurrence/path origin and distinct mode-origin state. |
| `SCI-FRUIT/RESPONSE/<RF-role>` | Exact response query, conditioning, scope and status. |
| `SCI-FRUIT/UNCERTAINTY/<role>` | Separately addressable target, conditioning, omissions and status. |
| `SCI-FRUIT/TERMINAL-SELECTION` | Separate immutable selector over completed iterations. |
| `SCI-FRUIT/TERMINAL-PRODUCT` | Selector and immutable selected completed bundle. |

Every product binds exact method, immutable parents, quantity/units/domain/support/origin, scientific state/application/iteration/branch/lineage and generation, status/cause and provenance. Underlying producer roles remain exact; these names create no generic numerical parent admission.

| State | Meaning and order |
| --- | --- |
| `not_requested` | No request exists. |
| `requested` | Exact request recorded. |
| `effective` | Declared effective action. |
| `application_scope_resolved` | Exact resolved scope and state. |
| `applied` | Resolved operation was invoked. |
| `iteration_realized` | Immutable numerical path values and execution outcomes exist. |
| `complete_iteration_candidate` | All required roles have values or core/method-permitted statuses. |
| `completion_decided` | Exact FRUIT-owned local completion decision exists. |
| `completed_iteration` | Candidate satisfies its exact local completion rule. |
| `published` | Immutable completed product exposed under its role. |
| `unavailable` | Terminal branch: affected missing/incompatible dependency, cause and scope. |
| `failed` | Terminal branch: failed action/decision and cause. |
| `not_produced` | Absence with cause and last reached stage. |
| `superseded` | Immutable replacement relation; old records remain. |

The first ten rows show successful local order; unavailable/failed/not-produced are terminal branches for the affected attempt, not later success stages. Preserve every reached record and fabricate none after early termination. Terminal selection consumes completed iterations without mutation. Downstream use is a separate immutable child decision and cannot erase local completion or create a new FRUIT iteration generation.
