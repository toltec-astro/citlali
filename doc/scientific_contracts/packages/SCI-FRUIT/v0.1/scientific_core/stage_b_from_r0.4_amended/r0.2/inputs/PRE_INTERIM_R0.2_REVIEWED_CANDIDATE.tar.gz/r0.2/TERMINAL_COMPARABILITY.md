# Terminal-candidate comparability

Sole normative authority: SCI-FRUIT-NORMATIVE-CORE v0.1/r0.2; canonical source-inventory SHA-256 `b02cff80eb4f1fb991214eb16d05a903f5dd3a363fe13461e83e5c96cf7411ed`. This is a derived navigation/evidence record, not independent science.

Canonical location: [Completion and terminal section](src/common/definitions.tex); REQ-020, PRED-016; ECS EV-014.

Candidates must share, or be mapped by exact selector-owned transformations into, common scientific quantity/role, unit/scale, frame/grid/domain, additive reference/gauge, response meaning, support comparison domain, method/generation relation and uncertainty/metric meaning. Equal shape or one common scalar does not establish comparability. Cross-method/route/grouping/gauge/generation/support conversions and comparisons are part of selector method identity.

Retain all nine fields: selected completed identity; every candidate/inclusion/exclusion/conversion; exact rule/generation/data access/ties/failure; convergence/stop/resource facts; causes; selected-terminal response; selected-terminal uncertainty; continuation/terminality; downstream named-use references/statuses. Unavailable comparisons and causes remain visible. Missing hard dependencies block selection. No last/latest/lowest-residual/visual default is supplied; selection adds an immutable record without modifying the chosen bundle.
