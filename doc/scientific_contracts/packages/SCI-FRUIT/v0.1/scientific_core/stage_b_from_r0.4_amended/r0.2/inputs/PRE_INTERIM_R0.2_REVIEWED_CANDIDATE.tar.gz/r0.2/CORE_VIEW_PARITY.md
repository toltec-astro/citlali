# Core/source/view parity - SCI-FRUIT v0.1/r0.2

The sole normative scientific core is six common LaTeX modules plus the core body. Its identity is SCI-FRUIT-NORMATIVE-CORE v0.1/r0.2 and exact source-inventory SHA-256 is `b02cff80eb4f1fb991214eb16d05a903f5dd3a363fe13461e83e5c96cf7411ed`.

All three wrappers import the same preamble, which imports those exact six modules and one deterministic digest-binding file. Only the core body invokes the complete normative content units. The rationale invokes canonical equation macros directly and cites selected core sections/requirements. The ECS cites that same scientific authority and presents prospective record/evidence/comparison procedures. Neither view redefines a canonical macro or imports the complete requirement/assumption/prediction registers as a second narrative.

| Exact content | Authority and parity control |
| --- | --- |
| Notation, typed spaces and ownership | One canonical notation/definition source, imported by all wrappers; no scientific redefinition in views. |
| Equations | One definition for each composition, map-valued expansion, full-linear, derivative, model-shift/bias, covariance and NOI macro. Rationale imports six of these verbatim; shift/bias is explained with core citation. ECS procedures cite exact REQ/PRED and quantity/conditioning contracts. |
| Product roles, state, support, RF and uncertainty | Complete definitions in the core, lossless derived navigation/crosswalk records and exact ECS requirement references. Logical scope agreement independently reviewed in round 3; inventory presence also mechanically checked. |
| Requirements and assumptions | Gap-free complete REQ-001--024 and ASM-001--006, each rendered once in the core. Rationale/ECS references do not replace these normative statements. |
| Predictions and evidence indexes | Gap-free PRED-001--020, each rendered once. Exactly 24 ECS requirement rows and 20 one-to-one prospective FIX design rows agree with machine indexes; every numerical result is not_assessed. |
| Source and PDF identities | All source-inventory rows reproduce. Covers carry the same core digest and distinct view-source digests. PDFs have distinct metadata titles and owner/revision/date/status agreement. Normal/clean builds reproduce every final PDF byte. |

This is common-source identity and semantic-scope parity, not a claim that the three differently purposed documents have identical prose or PDF bytes. All required scientific content remains in the normative core. [Document checks](reports/DOCUMENT_CHECKS.json), [semantic change report](SEMANTIC_CHANGE_REPORT.md), [independent review](review/REVIEW_REPORT.md), [clean build](reports/CLEAN_BUILD.md) and [visual/metadata report](reports/PDF_VISUAL_METADATA.md) provide the bounded evidence.
