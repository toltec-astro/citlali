# Author decision log - SCI-FRUIT v0.1/r0.2

Date: 2026-09-07. Scientific owner: Grant Wilson. Authoring decisions implement the exact supplied directive; they are not owner approvals.

1. Preserve the frozen Stage A packet/controls and accepted authored r0.1 delivery byte-exact under `inputs/`, retaining historical directory layout so relative links still resolve. Keep the Stage A archive opaque.
2. Establish the six common LaTeX modules plus core body as the sole normative scientific core. Convert all 24 crosswalk rows to complete normative statements; retain six assumptions and twenty predictions without appending IDs.
3. Scope RF-01/02 to fixed numerical maps/coefficient bindings; preserve the exact induced-map proof exception and RF-03 prescribed reruns. Add the general differentiable fixed-state chain rule and its complete-linear reduction.
4. Separate full-parent affine NOI members/centers from zero-centered perturbation action; preserve fixed-state, dependent-successor and relearned method boundaries.
5. Use exact pre-outcome conditioning and a separately named narrower fixed-realized-model target. Keep all four covariance terms for the random-model target. Type output shift before bias; preserve accepted-to-applied uncertainty/error transformations and separately addressable roles.
6. Define stable products and ordered actually-reached lifecycle records. Preserve all universal bundle/hard claim dependencies. Bind terminal-candidate conversions/comparison and all nine fields; make downstream use an immutable child decision.
7. Make the concise rationale an explanatory view that imports canonical equations. Make the ECS a prospective evidence procedure, with exact candidate/evidence tuples, four result values, 15 procedures, requirement/fixture indexes and a blank result template. No numerical fixtures or results are instantiated.
8. Use separate exact source inventories and one deterministic derived cover-binding file, avoiding self-reference. Keep build/resource identity and final PDF/artifact hashes separate.
9. Preserve readable 11-point scientific body text. Page targets are soft; core length is allowed to exceed twenty pages to retain complete requirements and predictions without tiny type or orphan paragraphs. Rationale and ECS remain within their specified reading targets.
10. Continue the existing independent review budget with one substantive round 3. Perform all-page rendering/inspection, exact source/input/link checks and a clean document build. These are document checks only, never numerical conformance.

No scientific method/route, reduction, replay, implementation assessment, numerical experiment, observational/performance/production or Unity activity is authorized or performed by these decisions. The final owner-review archive contains completed new r0.2 products and clearly labeled preserved inputs; no external in-progress snapshot is included.
