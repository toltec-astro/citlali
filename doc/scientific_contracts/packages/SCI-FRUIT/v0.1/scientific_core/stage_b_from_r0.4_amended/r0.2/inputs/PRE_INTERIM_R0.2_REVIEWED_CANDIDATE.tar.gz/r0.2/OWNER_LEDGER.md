# SCI-FRUIT v0.1 / r0.2 - owner ledger

Scientific owner: Grant Wilson. Stage B draft date: 2026-09-07.
This is a derived decision record, not a new scientific source or approval.

| Authority | Identity | State and limit |
| --- | --- | --- |
| A: program order | SCI-FRUIT-OD-PROGRAM-ORDER-2026-09-06 | Approved conditional authorship order only |
| B: conditional composition | SCI-FRUIT-OD-CONDITIONAL-COMPOSITION-2026-09-06 | Approved conditional scientific role composition only |
| C: numerical method | FRUIT-FEEDBACK-METHOD v0.1 | unavailable_pending_separate_owner_approval; family record approves no instance |

Every numerical instance needs `FRUIT-FEEDBACK-METHOD/<method-name>@<revision>`, its complete record, separate owner approval and upstream numerical authority. A/B do not imply C. All numerical route/model/operator/recurrence/grouping/support/learning/stopping/response/covariance/use-policy choices remain unavailable_pending_separate_owner_approval.

The approved final amendment SCI-FRUIT-OD-STAGE-A-FINAL-AMENDMENT-2026-09-07 preserves the type-method and micro-repair constraints under its exact scoped supersession. Their restatements are the only admitted authority; no original owner record was opened.

| Existing question | Current core disposition | Still unavailable and required resolution |
| --- | --- | --- |
| ODQ-001 recurrence | Conditional composition permitted; iteration alone selects no recurrence | Owner-approved exact numerical method |
| ODQ-001A carried state | S_k/S_(k+1) and complete scientific roles required | Actual model/state representation and realized bindings |
| ODQ-001B transition law | y_k^in rule, signs, Pi/F/B and update are distinct required method fields | Numerical transition and operation identities |
| ODQ-001C contribution meaning | Causal update, cumulative model, diagnostic difference and scientific product are distinct | Exact method-assigned increment role; no independent sky claim |
| ODQ-001D persistence | Scientific query vocabulary may be materialized/compact/reconstructible | Numerical persistence/reconstruction and failure contract |
| ODQ-001E comparison | Earlier owner-approved comparison framework retained | No new metric, tradeoff, population or benefit claim |
| ODQ-001F development/qualification | Earlier architecture retained; program-order authorship permission explicitly separated | Numerical development, qualification and policy evidence remain separately gated |
| ODQ-002 routes/grouping | One exact parent route and grouping; quantity/unit/response conventions conditional on route; no implicit compatibility or commutation | Every numerical parent route and grouping choice |
| ODQ-003 model | m_k^candidate, m_k^accepted and m_k^applied distinct, with explicit acceptance-to-application transformations; external/learned roles typed; feedback_model_state only | Numerical model, construction/acceptance/application, target representation and prior |
| ODQ-004 projector/rejoin | Typed conditional role order; exact bypass locations/counts required | Numerical Pi/F/B, inverse, affine terms, support/order choices |
| ODQ-005 learning/state | Seven operation/state categories; unchanged learning/recomputation rules retain method identity across new realized states | Numerical learning schedule, recomputation/selection rule and stochastic controls |
| ODQ-006 response | Seven explicitly scoped response roles; RF-03 local iteration and RF-07 composed parent-domain FRUIT-only query are distinct, with exact component references and derivative/finite-difference conventions | Numerical operators, response targets/fidelity and whole-chain authority |
| ODQ-007 support/failure | Required support/origin classes; undefined mismatch unavailable | Actual support/missing-data rules and exact failure actions |
| ODQ-008 stopping | Seven propositions and complete convergence/terminal-rule bindings required | Thresholds, resource limits, persistence values and numerical selector |
| ODQ-009 continuation/restart | Complete causal continuation criterion; restart new lineage; representation-only changes do not change state identity | Realized continuation sufficiency/compatibility under a numerical profile |
| ODQ-010 uncertainty | Joint conditional blocks, omitted sources, NOI fixed/dependent/relearned distinction | Any numerical covariance, uncertainty method or ensemble admission |
| ODQ-011 bundle/use | Universal minimum bundle and hard claim dependencies cannot be waived; narrower unavailable claims require core and method permission; terminal selection and downstream authority separate | Actual numerical result, publication/consumer fitness and persistence realization |
| ODQ-012 exact packet | Closed by SCI-FRUIT-OD-STAGE-A-R0.4-AMENDED-APPROVAL-2026-09-07 | Exact authoring launch authorized; no returned-core freeze or numerical admission follows |

The numerical questions remain deferred, not authoring blockers. No new scientific owner premise is required to state the generic conditional core. This draft does not decide the retained comparison framework, metric, tradeoff, population, benefit, development, qualification or policy evidence. Those known-but-unsupplied facts were not recovered from other material.

The next owner decision is review of the returned Stage B substance and possible conditional freeze. It is **pending**. Packet approval and authorship do not authorize that freeze or a numerical method. Independent review is advisory, not owner approval.

The seven response scopes and continuation/restart terminology are carried in the canonical core. No upstream science is superseded. See [decision log](DECISION_LOG.md), [source identities](SOURCE_IDENTITIES.md), and [canonical requirements](src/common/requirements.tex).

Numerical development, qualification and any policy recommendation retain their separate owner decisions and independent-pointing evidence obligations. The evidence plan is known-but-unsupplied here; none is invented. This carries forward the exact approved method-record boundary.

## r0.2 targeted revision disposition

The owner accepted the r0.1 conditional architecture as the basis for one targeted revision. [The exact directive](inputs/OWNER_DIRECTIVE_R0.2.txt) authorizes the scoped r0.2 repairs and three distinct reading documents. It does not freeze this revision or approve numerical methods. Stage A remains frozen at its exact preserved packet/approval/freezing controls. r0.1 remains immutable historical input.

RF-01/02 now fix numerical maps and every coefficient; prescribed unchanged-rule reruns belong to RF-03 unless the exact complete-induced-fixed-map proof applies. Fixed differentiable responses retain explicit tangent/conditioning premises. NOI distinguishes centered perturbation from full-product action and centers; stochastic conditioning is pre-outcome, with deliberately fixed realized-model targets separately named. Model-error transfer precedes any bias claim. Model-stage uncertainty, stable product/lifecycle roles, comparable immutable terminal selection and downstream child decisions are explicit.

These clarifications change conditional obligations only within the supplied directive. ODQ-001/001A--001F and ODQ-002--011 remain deferred numerical/producer choices. ODQ-012 remains closed for the Stage A launch. The returned r0.2 substance awaits Grant Wilson's separate review and possible conditional scientific freeze. No new numerical choice, evidence plan, owner approval or downstream policy is inferred.

Independent consistency review continues the same maximum-three-substantive-round budget: r0.1 used rounds 1 and 2; the targeted r0.2 candidate uses round 3. Its exact findings and disposition are in [review report](review/REVIEW_REPORT.md). The [proposed owner disposition](PROPOSED_OWNER_DISPOSITION.md) is explicitly a proposal, not an executed approval.
