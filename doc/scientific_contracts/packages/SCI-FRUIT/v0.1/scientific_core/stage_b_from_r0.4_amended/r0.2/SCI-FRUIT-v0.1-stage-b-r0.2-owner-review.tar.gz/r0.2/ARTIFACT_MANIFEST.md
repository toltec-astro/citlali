# Exact delivery manifest - SCI-FRUIT Stage B r0.2

Status: complete owner-review draft; Stage B not frozen. All numerical methods/routes remain unavailable_pending_separate_owner_approval; numerical comparisons blocked; evidence artifacts not produced.

Sole science: SCI-FRUIT-NORMATIVE-CORE v0.1/r0.2; canonical source-inventory SHA-256 e7f72712fa1c082bab8bfe8a279f9e568fec7f008fb8ac0cf2fcbae637e3cbcb.

Every regular delivery payload appears below once. Manifest self-hash is in ARTIFACT_MANIFEST.sha256. The archive contains these payloads plus manifest/sidecar, without symlinks or extra paths; archive/digest remain external and are not recursively embedded. Task caches, build intermediates, rendered PNGs and the separate external in-progress snapshot are excluded. Historical input archives are opaque member bytes, never relabeled r0.2 products.

| Path | Role | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| `.gitignore` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 58 | `a295b72d5cc4621b15f851b9d9b29fb526883ae09c849342f12f92f0dcf694a3` |
| `AMENDMENTS.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 3160 | `6e5d1068a632f89172adfa50b4665f09ef19d962b99b0af9a4de3c99d7bc820c` |
| `BUILD_RECIPE.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 4201 | `2622eef96b3726d9673f6653a4d7fe3e08883456d5cfbf141c06494766db359f` |
| `CORE_VIEW_PARITY.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 2577 | `8e8392a05f1e5af3b48ba2451d1c165336ab3dfe382c550d1c62a47b7c491813` |
| `DECISION_LOG.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 4310 | `69208357120af8ca59d4686b2243012df161e767377b78b933e666bd573184fd` |
| `DOCUMENT_VERIFICATION.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 4331 | `adbbca4177ce2194c839f65f23cad67fa794eaf93884ea9a2bcaaf923e3565ba` |
| `METHOD_RECORD_TEMPLATE.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 9714 | `bfeaa0eb80a7d231eb312c29f028e832610b2fa7c42c7b3983b202d46d7bc071` |
| `MODEL_UNCERTAINTY_CROSSWALK.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 1998 | `d4396d74ac80a177e2f3b32a388bd9888cd875e9012064b923f3dad135b26335` |
| `OWNER_LEDGER.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 8422 | `7e959de12575d908697dda43f10222ba25cd29dda406056a07e80e1b426eec92` |
| `PREDICTION_TO_FIXTURE.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 4743 | `2fe7f92210811d049af43348a55cd8ac79cdea07050e8d4cc8b147f8f127e92a` |
| `PRODUCT_LIFECYCLE.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 3614 | `39499951f48a23df4d2a4952c2f8cf7f8f4ad8040bdc04d7977f50910c522ce7` |
| `PROPOSED_OWNER_DISPOSITION.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 1875 | `029af5e3bfd9b730146f0b10f58356f7069ba6fea5fb1701e3eb9bb8e034871c` |
| `R0.1_TO_R0.2_CROSSWALK.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 24376 | `01ee40969ceff0b8bb76c241c90cd6e2d6d7949001a4594e5de831d06b80543e` |
| `README.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 4791 | `c7ea1d6522e9ef7ec8f97ae7f07cd7dbaee53dc77d354d8df9cc44700fa890d9` |
| `REQUIREMENT_TO_EVIDENCE.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 3717 | `b0ad5d0d93f66cfa1cefba6e818334048e3fe27827fc9d4170e59e85035ad6da` |
| `SEMANTIC_CHANGE_REPORT.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 5617 | `5e3bf8d7d6683d2c0e630c07e1d8fdc74aec45e9dabf00a11fa7b0682abb04e9` |
| `SOURCE_IDENTITIES.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 8283 | `8432b43f01166f06dfbd35b994396fc531c4cacc234a8eff85aa232212e4340d` |
| `TERMINAL_COMPARABILITY.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 1933 | `133630a063c75ce8c8643d015d9909d87c5c47ca398ca37f885002629715c6d9` |
| `evidence/CONFORMANCE_RESULT_TEMPLATE.json` | Prospective conformance record/index; numerical comparisons blocked; evidence artifacts not produced | 2989 | `059e88fc822895df9b62cf155735617b16c283e31dcc948b4b6e5bd4eca0f66f` |
| `evidence/INDEX_DATA.json` | Prospective conformance record/index; numerical comparisons blocked; evidence artifacts not produced | 15389 | `78bf289559edd13f31b6b07972c7c7c27587c7bdd0e9c026cd61d4007fdc5b30` |
| `identities/CORE_DOCUMENT_SOURCES.sha256` | Exact source/input or typesetting-resource identity inventory | 879 | `a5efcabae675dade4d63024483075d826d2b38caef9230d1b7527c78c2d09341` |
| `identities/CORE_SOURCES.sha256` | Exact source/input or typesetting-resource identity inventory | 637 | `e7f72712fa1c082bab8bfe8a279f9e568fec7f008fb8ac0cf2fcbae637e3cbcb` |
| `identities/ECS_DOCUMENT_SOURCES.sha256` | Exact source/input or typesetting-resource identity inventory | 961 | `e2e1dcbd2848febc9e790ae89abb0dfe45daa8222b1af77a45788d091c427455` |
| `identities/INPUT_FILES.sha256` | Exact source/input or typesetting-resource identity inventory | 7263 | `fb807b50b319bfeb0dc3fa77f34dbb456441ee64d10176e2c8f8e7a1b8d30969` |
| `identities/RATIONALE_DOCUMENT_SOURCES.sha256` | Exact source/input or typesetting-resource identity inventory | 973 | `b98289dda26c7eafade4b1eca048f08cb80acad3314ff2acffbaf1dbda093c61` |
| `identities/TEX_RESOURCES.sha256` | Exact source/input or typesetting-resource identity inventory | 49753 | `57e263922b731404210fdae3fa64b6926d749aa6d6c81b31116a6f042cc85514` |
| `inputs/OWNER_DIRECTIVE_R0.2.txt` | Exact preserved authority or historical input; not a new r0.2 reading product | 24206 | `d9980b2ebeaf03865d250b2f6af23c463b4268d62f848a4dea0f8d7405a2d713` |
| `inputs/OWNER_INTERIM_CORRECTION_R0.2.txt` | Exact preserved authority or historical input; not a new r0.2 reading product | 13175 | `53f32f2db4e131e11ca607b99d9519ecaa0fb7634017859c49d44a0c5549660a` |
| `inputs/PRE_INTERIM_R0.2_REVIEWED_CANDIDATE.tar.gz` | Exact preserved authority or historical input; not a new r0.2 reading product | 1234396 | `7cdefc3b43474647fc0cadd9c505efae8c769c381a58d82491cb165ed525cc1f` |
| `inputs/scientific_core/SCI_FRUIT_STAGE_A_R0.4_AMENDED_OWNER_APPROVAL_2026-09-07.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 5413 | `36fb05922951e77b4540c95192f639685b303a00d2831b772d83fb3ce78adb94` |
| `inputs/scientific_core/SCI_FRUIT_STAGE_A_R0.4_AMENDED_OWNER_FREEZE_2026-09-07.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 3612 | `754e81b3940f77f3bca067ba00a94f87707746d3c0bc9c6089487602de4c3aa8` |
| `inputs/scientific_core/SCI_FRUIT_STAGE_A_R0.4_AMENDED_OWNER_FREEZE_2026-09-07.md.sha256` | Exact preserved authority or historical input; not a new r0.2 reading product | 124 | `b6e09af09fac29143cadddc92c1c3a8c5d1bf5c5f35780b67f71ad30672c1c27` |
| `inputs/scientific_core/r0.4-amended/AUTHOR_INPUT_MANIFEST.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 18734 | `8d4099d31f48cad1e5bab0a04acffb377520ae2e619896b59e19ef08fd35c37d` |
| `inputs/scientific_core/r0.4-amended/AUTHOR_INPUT_MANIFEST.sha256` | Exact preserved authority or historical input; not a new r0.2 reading product | 91 | `0b15312f69ce593355a734ce8aa38b6e5b63ec997d148c4f19b07940bcd2982d` |
| `inputs/scientific_core/r0.4-amended/BOUNDARIES_AND_CONVENTIONS.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 16163 | `0321336a895348c29f94e61521b8523325fe8a598c81d0f3477a1def82828c7e` |
| `inputs/scientific_core/r0.4-amended/FRUIT_FEEDBACK_METHOD_REQUIRED_RECORD.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 9358 | `105dcbdd0751944b99716ad0568fae9bc255ca21771d435c70f8d9fdcebd0689` |
| `inputs/scientific_core/r0.4-amended/ITERATION_STATE_LIFECYCLE.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 14406 | `f80d6464af3a0a16ae4941b90eb7f89d3533e9d81cbb5558b256a90474636b5a` |
| `inputs/scientific_core/r0.4-amended/NOTATION_AND_ROLE_TAXONOMY.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 9624 | `9de22768791205ed50064f9540885754b97b86d934f36a97119ceb959a323874` |
| `inputs/scientific_core/r0.4-amended/PROGRAM_REFERENCE.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 8276 | `b42e8aa2080b09229ad76a6437196b3f9b49d25026c00cd1b4b16f3ed70fa380` |
| `inputs/scientific_core/r0.4-amended/PTC_APPLICATION_REFERENCE.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 1965 | `75116261a33ec1adbb092d38da43a590624a08428e51cac32ee0c4a34f216a59` |
| `inputs/scientific_core/r0.4-amended/REQUIRED_CONDITIONAL_PREDICTIONS.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 8846 | `7226c794af23caf82be5ffe7185796c8e1b8f9307b55b8de52cf707518b4aecc` |
| `inputs/scientific_core/r0.4-amended/RESPONSE_AND_UNCERTAINTY_FAMILIES.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 17921 | `9543a49236bbff12eeb31ca34da86f1f413717e07609cfacbdfb4be2e7170ea5` |
| `inputs/scientific_core/r0.4-amended/SCI-FRUIT-v0.1-stage-a-r0.4-amended-owner-review.tar.gz` | Exact preserved authority or historical input; not a new r0.2 reading product | 50299 | `654185e4a036b96350b6f2059f7986dc34e57eecbdd78a58695eeeb070bad9bd` |
| `inputs/scientific_core/r0.4-amended/SCI-FRUIT-v0.1-stage-a-r0.4-amended-owner-review.tar.gz.sha256` | Exact preserved authority or historical input; not a new r0.2 reading product | 122 | `d61a748684198bc40c94df3aaf97fda738dce66de50af21b33d937537876b660` |
| `inputs/scientific_core/r0.4-amended/SCIENTIFIC_OWNER_DECISION_LEDGER.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 16529 | `0c0b3407b17426a65a1489ad8a519868e469c172ad260ff8121c059cb15441a2` |
| `inputs/scientific_core/r0.4-amended/SCOPE_BRIEF.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 20205 | `0f3ed78489211ce73661101dbd451678d577e65157c4e91cf64db9f43e91f4e6` |
| `inputs/scientific_core/r0.4-amended/SUPPORT_INFORMATION_ORIGIN.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 5659 | `b7adaad809bc744cc86862a4c5b47ab019cc734c24e864a9271f1b69166d9aa5` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/.gitignore` | Exact preserved authority or historical input; not a new r0.2 reading product | 48 | `e05caa7d1145c97b5a78dfe50e1bf5b37321064d7574f416ea1e97186da6f4da` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/ARTIFACT_MANIFEST.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 4811 | `fd05799300adc704d086ca287da5e921f5e4fcf033188c39b785e052d9426f56` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/ARTIFACT_MANIFEST.sha256` | Exact preserved authority or historical input; not a new r0.2 reading product | 87 | `d1ae5a460fc3d86a3cf0e5eaf3d62c4b721ded6907e7cc5636e5566dc5250776` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/DECISION_LOG.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 3000 | `4ff006430ccc333f9ae3ad19c730f7d01b532629c3bc94731a2d2f9c9f3517b2` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/DOCUMENT_VERIFICATION.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 4621 | `1d3feb16847564026e02243e24128cf0acb8fc748efefbaeb4757d8fcb6c57b7` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/OWNER_LEDGER.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 6099 | `fa88ee2ef8bc981284b27d85f7685707127e25f9f2bf86e6b8678370f01c3b60` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/README.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 3729 | `cf8cb784963d522526afd5ab52dd4d1238c54bf3e481d8e9273d88ee1cf7a1a8` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/REQUIREMENT_CROSSWALK.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 7086 | `544a4997aeb87037665f2402f53ba802dea6865d6f891d5deb64cbd8fcc2d98c` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/SCI-FRUIT-v0.1-stage-b-r0.1-owner-review.tar.gz` | Exact preserved authority or historical input; not a new r0.2 reading product | 366495 | `74f9fb8c705bdbda364256e32b79084ea061b8ed4d3b698fbdd6529a80b60932` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/SCI-FRUIT-v0.1-stage-b-r0.1-owner-review.tar.gz.sha256` | Exact preserved authority or historical input; not a new r0.2 reading product | 114 | `f1d82f0b144bf34b12c452f5a71897164bb536062c5ad93a2eb7248b17d67e0e` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/SOURCE_IDENTITIES.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 3555 | `62234297084d11e5c7b328cafd495a90fc41f464c9f376833a155a6c23117213` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/pdf/engineering.pdf` | Exact preserved authority or historical input; not a new r0.2 reading product | 160386 | `d66e3f96ebcd8aaaf1c8958e828fd6d8c1489b3fbe1669f21a4702f0fe01b671` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/pdf/scientist.pdf` | Exact preserved authority or historical input; not a new r0.2 reading product | 160449 | `5a511ce26952bf1c81453f282406f5a1aa99a7208ce95ad52f509d1c857c6708` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/qa/DOCUMENT_CHECKS.json` | Exact preserved authority or historical input; not a new r0.2 reading product | 742 | `92b9a438cb94f3faf488335083c2ceb85f681f973ef47da94e51e25ed228ea79` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/qa/PAGE_INSPECTION.json` | Exact preserved authority or historical input; not a new r0.2 reading product | 1391 | `01abc34fe8bd4996ff7aef1a61226c77e89a2e1c73e5bd8bbe19afed71452b5e` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/qa/build_documents.py` | Exact preserved authority or historical input; not a new r0.2 reading product | 2447 | `8c3bc63e83854db5d58a3874959e11d71b7142c95fc141711c2122d5bb538f3b` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/qa/package_documents.py` | Exact preserved authority or historical input; not a new r0.2 reading product | 3399 | `e65e6a2d60ea596a9a4525a7b996de259dae9dda39d0f0073c2b2b09a39077e9` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/qa/verify_documents.py` | Exact preserved authority or historical input; not a new r0.2 reading product | 6918 | `8a796de8b53e46ebe7eac67538ab29849197d5a047b75334916517bf5d26adcc` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/review/REVIEW_REPORT.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 1980 | `b0d714f071bf00485b5e1427d81607106ab907bd4e47e1abf4c01e878c87e017` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/review/ROUND_1.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 15328 | `2ceee86dcd965bebf1c394fe0de81db1022baa9d19560c196fccf325774b8d27` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/review/ROUND_2.md` | Exact preserved authority or historical input; not a new r0.2 reading product | 8811 | `7a4bf3da39155e082f667b3671f1af37857f0a07c3486aab5ec5eaf3b2ff1663` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/PTC_APPLICATION_REFERENCE.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 1965 | `75116261a33ec1adbb092d38da43a590624a08428e51cac32ee0c4a34f216a59` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/assumptions.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 6207 | `fd6a5b2b1e4600572a817296bdcc2b4e78d041521b6071a0bacb5818c0489e48` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/definitions.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 20919 | `855125eed78291260fd8fa8d404ff0c80f8e0c46a389ee44c4097ec1d5545db9` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/edge_cases.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 11025 | `096ce88b977787484774ab7238746dcbd93ab2e710bf78410cb5347f8f96d2b0` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/equations.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 13617 | `493f9112011efc1350766817ab1266deefc65a2ff703e480c1e13c1fb89082f8` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/notation.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 6002 | `f92171e25d98e94250dfeafbabe62dcefc4fbbe0d22210f7488c78cecc42a636` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/requirements.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 19300 | `6e1b207987045f5668080f40f1641e6396e60f13d62e7a87a7b3764599b28fd1` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/engineering.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 211 | `2c7eaaaf742a7021424993fe3692d4869d9dce65b87173a37d96a6642dbb63f5` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/preamble.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 1488 | `8aeed88f89932684454be12ac064ec1c86fca4021c0ef356d0408e787c9cab86` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/scientist.tex` | Exact preserved authority or historical input; not a new r0.2 reading product | 208 | `3d4b8f777936fdc77bdcbf9f41b8043788f4f30327d636e7dda84ea48f06ccef` |
| `pdf/core.pdf` | Completed r0.2 owner-review PDF | 142046 | `dc0dbd4baef96c2fbf3079eef4eb21d91537bf0abf4cb000edfaeedeb579cb46` |
| `pdf/ecs.pdf` | Completed r0.2 owner-review PDF | 81167 | `4db23ca696ee6922e37fc36da3cd0e10c03d8b2ed0bfa4d972e5ab6411810d49` |
| `pdf/rationale.pdf` | Completed r0.2 owner-review PDF | 73802 | `36339bbc973359e49c2fe6765901d2542c3d2bca96febedf5598c116835ea508` |
| `reports/BUILD_RECORD.json` | Document-only build, verification or evidence | 4188 | `72130270a7d38c3db2accd622886e13dd5e1b8e3738813e6685bfe522993b2e5` |
| `reports/CLEAN_BUILD.md` | Document-only build, verification or evidence | 1416 | `b62829b32657627f788c43328c7b3f38fd3f4a1598c4c7f2b9c2e789bb028740` |
| `reports/DOCUMENT_CHECKS.json` | Document-only build, verification or evidence | 4106 | `6e01f4ffa772e4b201bf81369018db71bf11e5592d8d54ac89a2f9a5f775a4c3` |
| `reports/PAGE_INSPECTION.json` | Document-only build, verification or evidence | 6220 | `f76214ccb523e1debc48c9a2a2934ab7983c8701e1a3a69ff0c642e25b9f4c96` |
| `reports/PDF_VISUAL_METADATA.md` | Document-only build, verification or evidence | 2108 | `a0f0fd325d9ee5b316edc55e00a9e44b8c4a7da14c662df9d4d0813a799ed274` |
| `review/INTERIM_CORRECTION_REVIEW.md` | Bounded independent consistency review; advisory | 25014 | `91201ab4cb8d37c38be18b1562975bd965f8433da039b7d90933b4b264463cc9` |
| `review/REVIEW_REPORT.md` | Bounded independent consistency review; advisory | 2186 | `a401bbb9153f3189053896a217d96b7d2322bff7ce3f167a73a81d3d824aa29c` |
| `review/ROUND_3.md` | Bounded independent consistency review; advisory | 24502 | `2f5c2122b0223ef1bc0ad3a51454f355b2e179a40df4e3c1f3e657d75f47282e` |
| `src/bindings.tex` | Distinct document view, shared layout or deterministic digest binding | 1680 | `ddbae6815107c86f33b5a80a15a669ea52a84131f834f29334e592e2a8180332` |
| `src/common/assumptions.tex` | Sole normative scientific-core source | 3353 | `0f154e9d8c07f04b4d3bdd363b4b2b5cff5b6a06bfd5284171bdb84f0b2d2c00` |
| `src/common/definitions.tex` | Sole normative scientific-core source | 24056 | `d47092f44efd6591a98c27060d2dc6df339aeecf2e7ca3966bdd44b6fcdd091d` |
| `src/common/edge_cases.tex` | Sole normative scientific-core source | 10834 | `c889b7f40c3aa22f7083369ca9e9c4eff6c43d6239c0013614d89e5d4db1f8bd` |
| `src/common/equations.tex` | Sole normative scientific-core source | 17816 | `9894158f1d865820e053cdbd55ccd84c8d486441005cbdedcc42fdf1a6260f6c` |
| `src/common/notation.tex` | Sole normative scientific-core source | 3929 | `ba8b2195eeac6442cb77e431a83d844ba15d0e7bdb446c87036ce2914c123092` |
| `src/common/requirements.tex` | Sole normative scientific-core source | 18822 | `4ef05a1c356cd576c7b669210663d17998c1c96a2ca071dd27e05da9fd7a3831` |
| `src/core.tex` | Distinct document view, shared layout or deterministic digest binding | 404 | `86ea0924b03509deef14f8b06dff893592c6cb04b7f081283ca1db29eca250ea` |
| `src/core_body.tex` | Sole normative scientific-core source | 264 | `e95d549bdefe76b6ffb35488c5f5e4206273103791418fc9fa2473b51c9bc29b` |
| `src/cover.tex` | Distinct document view, shared layout or deterministic digest binding | 1777 | `00846af070d07e022931875f720b3e59561b2aa894950f327500f0e04b540801` |
| `src/ecs.tex` | Distinct document view, shared layout or deterministic digest binding | 440 | `979cea37f4f829cd8afca37b4a61f3f3b9a694e16545ee86c653fb225a2da2c7` |
| `src/ecs_body.tex` | Distinct document view, shared layout or deterministic digest binding | 31732 | `9044abfda6161dbc7ad83c8c8df0e3dcd50fde1a43c1e9838b66e914d052ba8d` |
| `src/preamble.tex` | Distinct document view, shared layout or deterministic digest binding | 1434 | `10eb587fd34d22fd274e9902243e1362a7778d96a8fc67cf06607581ebe6f614` |
| `src/rationale.tex` | Distinct document view, shared layout or deterministic digest binding | 432 | `c13f814fcf3ea1a2ec14e98fa38a323af32ee64230123093b385e2f7e460e23f` |
| `src/rationale_body.tex` | Distinct document view, shared layout or deterministic digest binding | 16337 | `9b3b73b872fb70cd02289154f1b48d3d61f202bbe6457f34a9f89f86c6c3a68c` |
| `tools/build_documents.py` | Document-only build, verification or evidence | 7281 | `6566c0bba9cbe97ead773bf633c568074c62b79554f5406532ca0e319795961e` |
| `tools/package_documents.py` | Document-only build, verification or evidence | 4945 | `fd6edd9c69b673cdcfa7138f70da4a3380971da363af13a24e8405cbf1902fbc` |
| `tools/verify_documents.py` | Document-only build, verification or evidence | 13507 | `4c940cc06e67a5ffb3ff27a7585ebfb03c6f1fc266611e8980b8f71530ded6bb` |
