# Document verification - SCI-FRUIT v0.1/r0.2

Date: 2026-09-07. Scope: the new r0.2 document packet only. Stage A and r0.1 are preserved byte-exact; all numerical methods/routes remain unavailable and numerical conformance unassessed.

| Check | Evidence and bounded result |
| --- | --- |
| Exact scientific read/authority set | Eleven admitted Stage A payloads and permission controls reproduce historical identities. Exact new directive, frozen Stage A archive/controls and entire r0.1 delivery are preserved and separately labeled under inputs. No archive is unpacked for science. |
| Sole normative authority | Six canonical modules plus core body bind one exact core source-inventory digest; 24 complete requirements, six assumptions and twenty predictions remain gap-free and rendered once. All wrappers bind the same core. |
| Targeted science and independent review | [Round 3](review/ROUND_3.md) found no scientific inconsistency, inherited omission or new owner premise, within the existing three-round maximum. Every one of its 55 reviewed file identities is reverified at closure. Owner review/freeze remains pending. |
| Three distinct document roles | Core has full normative science; rationale imports selected canonical equations; ECS has exact candidate/evidence records, 15 procedures, 24 requirement links, twenty prospective fixture designs and a blank result contract. No numeric fixture is instantiated or marked pass. |
| Source and semantic parity | [Core/view parity](CORE_VIEW_PARITY.md) and [semantic report](SEMANTIC_CHANGE_REPORT.md) identify exact canonical definitions and scoped owner-directed repairs; source inventories and view imports reproduce. |
| Clean document build | Independent source/output directories and fresh format cache produce all three PDFs with identical bytes to normal builds; zero checked TeX warnings/overfull/underfull/undefined-reference/missing-character errors. [Evidence](reports/CLEAN_BUILD.md). |
| Visual and metadata | All 44 pages rendered/reopened and inspected: 22 core, nine rationale, thirteen ECS. No open layout/glyph/table defects. Covers bind correct owner/identity/revision/status/date, exact source/control digests and build identity; distinct PDF metadata titles agree. [Evidence](reports/PDF_VISUAL_METADATA.md). |
| Links and source closure | Every delivered local Markdown link resolves within the archive tree, including preserved-input links. TeX includes and PDF named destinations resolve; source/input/sidecar hashes reproduce. |
| Exact delivery closure | [Manifest](ARTIFACT_MANIFEST.md) binds all regular payload bytes; its [sidecar](ARTIFACT_MANIFEST.sha256) binds the manifest. The [archive](SCI-FRUIT-v0.1-stage-b-r0.2-owner-review.tar.gz) contains exactly those payloads plus manifest/sidecar; its [external digest](SCI-FRUIT-v0.1-stage-b-r0.2-owner-review.tar.gz.sha256) binds the complete gzip bytes. No symlink, transient cache/build/render or external in-progress snapshot is included. |

[DOCUMENT_CHECKS.json](reports/DOCUMENT_CHECKS.json) retains exact mechanical counts and final PDF metadata/hashes. Tools are restricted to document build, identity and archive checks. Runtime prerequisites and resource inventory are specified in [build recipe](BUILD_RECIPE.md); unspecified other toolchains are not claimed byte-reproducible.

Routine authoring/tool defects were repaired locally: Python string quoting, a table column escape/overflow, overflowing page breaks and duplicated citation punctuation. The final scientific source needed no independent-review repair. None of these repairs changed a numerical method, gate, bound, external scientific input, interpretation scope or replay/reduction count. No numerical or Unity activity occurred.
