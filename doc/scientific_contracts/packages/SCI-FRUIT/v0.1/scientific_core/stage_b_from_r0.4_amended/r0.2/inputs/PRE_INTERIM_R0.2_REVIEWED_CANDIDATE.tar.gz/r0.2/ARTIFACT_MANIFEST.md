# Exact delivery manifest - SCI-FRUIT Stage B r0.2

Status: complete owner-review draft; Stage B not frozen. All numerical methods/routes remain unavailable_pending_separate_owner_approval; numerical conformance not_assessed.

Sole science: SCI-FRUIT-NORMATIVE-CORE v0.1/r0.2; canonical source-inventory SHA-256 b02cff80eb4f1fb991214eb16d05a903f5dd3a363fe13461e83e5c96cf7411ed.

Every regular delivery payload appears below once. Manifest self-hash is in ARTIFACT_MANIFEST.sha256. The archive contains these payloads plus manifest/sidecar, without symlinks or extra paths; archive/digest remain external and are not recursively embedded. Task caches, build intermediates, rendered PNGs and the separate external in-progress snapshot are excluded. Historical input archives are opaque member bytes, never relabeled r0.2 products.

| Path | Role | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| `.gitignore` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 58 | `a295b72d5cc4621b15f851b9d9b29fb526883ae09c849342f12f92f0dcf694a3` |
| `AMENDMENTS.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 2638 | `3c66c3686e1877e912da112936354733ed1ec65b4cca462d71c511a2d951e255` |
| `BUILD_RECIPE.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 4170 | `14da3f5196ef32b59ff3858cd52ea344a01cf85babad4cd617f616fdc3712b33` |
| `CORE_VIEW_PARITY.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 2790 | `40c9789a4f057e5b5b93078da38a99b6ee58eca60b756a9a57f41b02af9b495f` |
| `DECISION_LOG.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 2921 | `68eafb33319f506058cc08d84c695f83f79b09fbb83b297af4b9c4b041254c2d` |
| `DOCUMENT_VERIFICATION.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 3747 | `a348b0e1ca1b5b190976f56612699f03cc21836db92426df5c22ff8b06ed9acb` |
| `METHOD_RECORD_TEMPLATE.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 9154 | `8b8513113fba957f0d3ca557134ce0270f16ddadb6f9f53f45b517a4f6164a27` |
| `MODEL_UNCERTAINTY_CROSSWALK.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 2791 | `f63c1c509ea485bce66b0be611c7ac770544ad88218cdc404bab186f000fbe46` |
| `OWNER_LEDGER.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 7898 | `8c89946f8add6d55cd69deec6b7d397b4e5a38469faa8e36c41c02dda64cae98` |
| `PREDICTION_TO_FIXTURE.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 4473 | `fdd78e32e7e373ada5b0d997995b8999eaf428bdcc818f275c8b740cd05318bd` |
| `PRODUCT_LIFECYCLE.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 3081 | `37c894ab7bbfcd2d8d2db9711d56c7b4192b60984e09e6a60f9bb920201c56a9` |
| `PROPOSED_OWNER_DISPOSITION.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 1601 | `f39d9f018c39a26d8fa187ed7e574e239066a21695d901d078824ffcc0ebba12` |
| `README.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 4572 | `f93dcc99da7da97bb085e22749b8afa14108e3e0d95f3467be1fca663ad691ef` |
| `REQUIREMENT_TO_EVIDENCE.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 3365 | `f2221e216582c070c37d9b7f01777fd55dd72bd32809ad644eaeb1c36a969945` |
| `SEMANTIC_CHANGE_REPORT.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 4564 | `d5e90a7d58823b0d2f5ee348f5154d944d066a7b398d833003650607693a9778` |
| `SOURCE_IDENTITIES.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 6375 | `05f62c906a7dbd22bf3f1e76a93b7a7acba21245bf8f35924635fcb81cbdde25` |
| `TERMINAL_COMPARABILITY.md` | Document navigation, authority ledger, derived crosswalk or disposition proposal | 1393 | `3df2920e6765b21fe18cafd0b202dc63f833797e6ce2cb82a7eef4894bbec141` |
| `evidence/CONFORMANCE_RESULT_TEMPLATE.json` | Prospective conformance record/index; numerical results unassessed | 2020 | `03a22f076e0b3547de78d6b4fe8df27e3d485f2dcd6917331a01fc26483dff9b` |
| `evidence/INDEX_DATA.json` | Prospective conformance record/index; numerical results unassessed | 12894 | `d5887047e76f1d9b8d2f16157b715a60476b315476e76a5b3946937feebdfd8e` |
| `identities/CORE_DOCUMENT_SOURCES.sha256` | Exact source/input or typesetting-resource identity inventory | 879 | `d314b825dbe1587110bc25990ed5c0ade44c554d9b0c433b22eebdb591fab577` |
| `identities/CORE_SOURCES.sha256` | Exact source/input or typesetting-resource identity inventory | 637 | `b02cff80eb4f1fb991214eb16d05a903f5dd3a363fe13461e83e5c96cf7411ed` |
| `identities/ECS_DOCUMENT_SOURCES.sha256` | Exact source/input or typesetting-resource identity inventory | 961 | `a3535c86e80a896bcd54e0a7b06cef655696756b50d94bf60ac8d31aef1f3427` |
| `identities/INPUT_FILES.sha256` | Exact source/input or typesetting-resource identity inventory | 7040 | `58a369350f5f914f6f6b91f114a49941bfdd1e2ce31d3ee3776fa450cbc0de45` |
| `identities/RATIONALE_DOCUMENT_SOURCES.sha256` | Exact source/input or typesetting-resource identity inventory | 973 | `2ec807f00f84b5e32a3fb420b448c67649efd1cd516c6f6be16d551130475db3` |
| `identities/TEX_RESOURCES.sha256` | Exact source/input or typesetting-resource identity inventory | 49753 | `57e263922b731404210fdae3fa64b6926d749aa6d6c81b31116a6f042cc85514` |
| `inputs/OWNER_DIRECTIVE_R0.2.txt` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 24206 | `d9980b2ebeaf03865d250b2f6af23c463b4268d62f848a4dea0f8d7405a2d713` |
| `inputs/scientific_core/SCI_FRUIT_STAGE_A_R0.4_AMENDED_OWNER_APPROVAL_2026-09-07.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 5413 | `36fb05922951e77b4540c95192f639685b303a00d2831b772d83fb3ce78adb94` |
| `inputs/scientific_core/SCI_FRUIT_STAGE_A_R0.4_AMENDED_OWNER_FREEZE_2026-09-07.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 3612 | `754e81b3940f77f3bca067ba00a94f87707746d3c0bc9c6089487602de4c3aa8` |
| `inputs/scientific_core/SCI_FRUIT_STAGE_A_R0.4_AMENDED_OWNER_FREEZE_2026-09-07.md.sha256` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 124 | `b6e09af09fac29143cadddc92c1c3a8c5d1bf5c5f35780b67f71ad30672c1c27` |
| `inputs/scientific_core/r0.4-amended/AUTHOR_INPUT_MANIFEST.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 18734 | `8d4099d31f48cad1e5bab0a04acffb377520ae2e619896b59e19ef08fd35c37d` |
| `inputs/scientific_core/r0.4-amended/AUTHOR_INPUT_MANIFEST.sha256` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 91 | `0b15312f69ce593355a734ce8aa38b6e5b63ec997d148c4f19b07940bcd2982d` |
| `inputs/scientific_core/r0.4-amended/BOUNDARIES_AND_CONVENTIONS.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 16163 | `0321336a895348c29f94e61521b8523325fe8a598c81d0f3477a1def82828c7e` |
| `inputs/scientific_core/r0.4-amended/FRUIT_FEEDBACK_METHOD_REQUIRED_RECORD.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 9358 | `105dcbdd0751944b99716ad0568fae9bc255ca21771d435c70f8d9fdcebd0689` |
| `inputs/scientific_core/r0.4-amended/ITERATION_STATE_LIFECYCLE.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 14406 | `f80d6464af3a0a16ae4941b90eb7f89d3533e9d81cbb5558b256a90474636b5a` |
| `inputs/scientific_core/r0.4-amended/NOTATION_AND_ROLE_TAXONOMY.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 9624 | `9de22768791205ed50064f9540885754b97b86d934f36a97119ceb959a323874` |
| `inputs/scientific_core/r0.4-amended/PROGRAM_REFERENCE.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 8276 | `b42e8aa2080b09229ad76a6437196b3f9b49d25026c00cd1b4b16f3ed70fa380` |
| `inputs/scientific_core/r0.4-amended/PTC_APPLICATION_REFERENCE.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 1965 | `75116261a33ec1adbb092d38da43a590624a08428e51cac32ee0c4a34f216a59` |
| `inputs/scientific_core/r0.4-amended/REQUIRED_CONDITIONAL_PREDICTIONS.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 8846 | `7226c794af23caf82be5ffe7185796c8e1b8f9307b55b8de52cf707518b4aecc` |
| `inputs/scientific_core/r0.4-amended/RESPONSE_AND_UNCERTAINTY_FAMILIES.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 17921 | `9543a49236bbff12eeb31ca34da86f1f413717e07609cfacbdfb4be2e7170ea5` |
| `inputs/scientific_core/r0.4-amended/SCI-FRUIT-v0.1-stage-a-r0.4-amended-owner-review.tar.gz` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 50299 | `654185e4a036b96350b6f2059f7986dc34e57eecbdd78a58695eeeb070bad9bd` |
| `inputs/scientific_core/r0.4-amended/SCI-FRUIT-v0.1-stage-a-r0.4-amended-owner-review.tar.gz.sha256` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 122 | `d61a748684198bc40c94df3aaf97fda738dce66de50af21b33d937537876b660` |
| `inputs/scientific_core/r0.4-amended/SCIENTIFIC_OWNER_DECISION_LEDGER.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 16529 | `0c0b3407b17426a65a1489ad8a519868e469c172ad260ff8121c059cb15441a2` |
| `inputs/scientific_core/r0.4-amended/SCOPE_BRIEF.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 20205 | `0f3ed78489211ce73661101dbd451678d577e65157c4e91cf64db9f43e91f4e6` |
| `inputs/scientific_core/r0.4-amended/SUPPORT_INFORMATION_ORIGIN.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 5659 | `b7adaad809bc744cc86862a4c5b47ab019cc734c24e864a9271f1b69166d9aa5` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/.gitignore` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 48 | `e05caa7d1145c97b5a78dfe50e1bf5b37321064d7574f416ea1e97186da6f4da` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/ARTIFACT_MANIFEST.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 4811 | `fd05799300adc704d086ca287da5e921f5e4fcf033188c39b785e052d9426f56` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/ARTIFACT_MANIFEST.sha256` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 87 | `d1ae5a460fc3d86a3cf0e5eaf3d62c4b721ded6907e7cc5636e5566dc5250776` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/DECISION_LOG.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 3000 | `4ff006430ccc333f9ae3ad19c730f7d01b532629c3bc94731a2d2f9c9f3517b2` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/DOCUMENT_VERIFICATION.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 4621 | `1d3feb16847564026e02243e24128cf0acb8fc748efefbaeb4757d8fcb6c57b7` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/OWNER_LEDGER.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 6099 | `fa88ee2ef8bc981284b27d85f7685707127e25f9f2bf86e6b8678370f01c3b60` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/README.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 3729 | `cf8cb784963d522526afd5ab52dd4d1238c54bf3e481d8e9273d88ee1cf7a1a8` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/REQUIREMENT_CROSSWALK.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 7086 | `544a4997aeb87037665f2402f53ba802dea6865d6f891d5deb64cbd8fcc2d98c` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/SCI-FRUIT-v0.1-stage-b-r0.1-owner-review.tar.gz` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 366495 | `74f9fb8c705bdbda364256e32b79084ea061b8ed4d3b698fbdd6529a80b60932` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/SCI-FRUIT-v0.1-stage-b-r0.1-owner-review.tar.gz.sha256` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 114 | `f1d82f0b144bf34b12c452f5a71897164bb536062c5ad93a2eb7248b17d67e0e` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/SOURCE_IDENTITIES.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 3555 | `62234297084d11e5c7b328cafd495a90fc41f464c9f376833a155a6c23117213` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/pdf/engineering.pdf` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 160386 | `d66e3f96ebcd8aaaf1c8958e828fd6d8c1489b3fbe1669f21a4702f0fe01b671` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/pdf/scientist.pdf` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 160449 | `5a511ce26952bf1c81453f282406f5a1aa99a7208ce95ad52f509d1c857c6708` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/qa/DOCUMENT_CHECKS.json` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 742 | `92b9a438cb94f3faf488335083c2ceb85f681f973ef47da94e51e25ed228ea79` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/qa/PAGE_INSPECTION.json` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 1391 | `01abc34fe8bd4996ff7aef1a61226c77e89a2e1c73e5bd8bbe19afed71452b5e` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/qa/build_documents.py` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 2447 | `8c3bc63e83854db5d58a3874959e11d71b7142c95fc141711c2122d5bb538f3b` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/qa/package_documents.py` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 3399 | `e65e6a2d60ea596a9a4525a7b996de259dae9dda39d0f0073c2b2b09a39077e9` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/qa/verify_documents.py` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 6918 | `8a796de8b53e46ebe7eac67538ab29849197d5a047b75334916517bf5d26adcc` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/review/REVIEW_REPORT.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 1980 | `b0d714f071bf00485b5e1427d81607106ab907bd4e47e1abf4c01e878c87e017` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/review/ROUND_1.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 15328 | `2ceee86dcd965bebf1c394fe0de81db1022baa9d19560c196fccf325774b8d27` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/review/ROUND_2.md` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 8811 | `7a4bf3da39155e082f667b3671f1af37857f0a07c3486aab5ec5eaf3b2ff1663` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/PTC_APPLICATION_REFERENCE.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 1965 | `75116261a33ec1adbb092d38da43a590624a08428e51cac32ee0c4a34f216a59` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/assumptions.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 6207 | `fd6a5b2b1e4600572a817296bdcc2b4e78d041521b6071a0bacb5818c0489e48` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/definitions.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 20919 | `855125eed78291260fd8fa8d404ff0c80f8e0c46a389ee44c4097ec1d5545db9` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/edge_cases.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 11025 | `096ce88b977787484774ab7238746dcbd93ab2e710bf78410cb5347f8f96d2b0` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/equations.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 13617 | `493f9112011efc1350766817ab1266deefc65a2ff703e480c1e13c1fb89082f8` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/notation.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 6002 | `f92171e25d98e94250dfeafbabe62dcefc4fbbe0d22210f7488c78cecc42a636` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/common/requirements.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 19300 | `6e1b207987045f5668080f40f1641e6396e60f13d62e7a87a7b3764599b28fd1` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/engineering.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 211 | `2c7eaaaf742a7021424993fe3692d4869d9dce65b87173a37d96a6642dbb63f5` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/preamble.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 1488 | `8aeed88f89932684454be12ac064ec1c86fca4021c0ef356d0408e787c9cab86` |
| `inputs/scientific_core/stage_b_from_r0.4_amended/r0.1/src/scientist.tex` | Exact preserved authority or historical r0.1 input; not a new r0.2 reading product | 208 | `3d4b8f777936fdc77bdcbf9f41b8043788f4f30327d636e7dda84ea48f06ccef` |
| `pdf/core.pdf` | Completed r0.2 owner-review PDF | 127182 | `71423b2a7434aa9491dc4ef89ee79a479684e1b47dc497e96c314dbd129d9876` |
| `pdf/ecs.pdf` | Completed r0.2 owner-review PDF | 78083 | `a85e50a9b5622e3dd67fdb6d8aa9085cc31bcf6bb4c521f58a09e6844e89fbba` |
| `pdf/rationale.pdf` | Completed r0.2 owner-review PDF | 70566 | `eef8100feefd743fac2d4bcd6188ecd37f089c108bfdfdc290bcbbfccf6b6926` |
| `reports/BUILD_RECORD.json` | Document-only build, verification or evidence | 4015 | `732804b5f8a2715bde1f001bc8b53e83c89aa22862c9695e914c2392f4a516f0` |
| `reports/CLEAN_BUILD.md` | Document-only build, verification or evidence | 1467 | `c89068dd1317a9ccca1c3dbea560ff84f456080063f2af74839e9174e5d5e69f` |
| `reports/DOCUMENT_CHECKS.json` | Document-only build, verification or evidence | 3142 | `6816bc76c0ea07fc26badd1ed1557419c54d9f5ee65eb080962925f278f1f88a` |
| `reports/PAGE_INSPECTION.json` | Document-only build, verification or evidence | 5832 | `711670eb372b6113e6b1fc7d0f04820f0ddb191fd8944795a8f9a961e0926877` |
| `reports/PDF_VISUAL_METADATA.md` | Document-only build, verification or evidence | 2256 | `11c06f7cce179c5593e0fdc3f5680c24da432d001027f404cf61941773c76576` |
| `review/REVIEW_REPORT.md` | Bounded independent consistency review; advisory | 1654 | `3a03171c38d49e1956d7c345805792c663045a39323133d2627dd1c2a2910a47` |
| `review/ROUND_3.md` | Bounded independent consistency review; advisory | 24502 | `2f5c2122b0223ef1bc0ad3a51454f355b2e179a40df4e3c1f3e657d75f47282e` |
| `src/bindings.tex` | Distinct document view, shared layout or deterministic digest binding | 1329 | `21389187ffc5e54b7582f9585ef6eb83597dba92cacc2d73e4ea129c11796d11` |
| `src/common/assumptions.tex` | Sole normative scientific-core source | 3828 | `245b1059b2d720eee8b9b2673c50f766c5e48a106f2fe21fdc10218c636a779e` |
| `src/common/definitions.tex` | Sole normative scientific-core source | 18177 | `3c89578d7ff07b133586fe2d74619d026f3e43da13f2ee41bacab5af4fdb351f` |
| `src/common/edge_cases.tex` | Sole normative scientific-core source | 10366 | `2a6c1048cb5785a0db7232865bc165733d08a73a95ff45023733e1c7ee3791dc` |
| `src/common/equations.tex` | Sole normative scientific-core source | 17661 | `fbbd121455e4436d0fcdb4be607dae9ac3630e1264c70a16ff646033fa1c5802` |
| `src/common/notation.tex` | Sole normative scientific-core source | 3608 | `e591266f113585981081737f0169e25290e07b240bb7a415434bbb61a5c43786` |
| `src/common/requirements.tex` | Sole normative scientific-core source | 17630 | `8b3de7519c78489a908ef688fea4f48a68ba88b569dd957b3aad6347faa531c7` |
| `src/core.tex` | Distinct document view, shared layout or deterministic digest binding | 404 | `86ea0924b03509deef14f8b06dff893592c6cb04b7f081283ca1db29eca250ea` |
| `src/core_body.tex` | Sole normative scientific-core source | 211 | `5160624376550e4ff8ae5b20f5d375bb8b51988cb9cc33c857d4c613218645b4` |
| `src/cover.tex` | Distinct document view, shared layout or deterministic digest binding | 1514 | `91f34073ca6bb4256ffed93b08037402bdd2a7506c65222d5498499a54516d5a` |
| `src/ecs.tex` | Distinct document view, shared layout or deterministic digest binding | 440 | `979cea37f4f829cd8afca37b4a61f3f3b9a694e16545ee86c653fb225a2da2c7` |
| `src/ecs_body.tex` | Distinct document view, shared layout or deterministic digest binding | 29700 | `6374e519681217762b0cf83160aadf78b33b5c679c6371ad1e9c0879b4db235a` |
| `src/preamble.tex` | Distinct document view, shared layout or deterministic digest binding | 1434 | `10eb587fd34d22fd274e9902243e1362a7778d96a8fc67cf06607581ebe6f614` |
| `src/rationale.tex` | Distinct document view, shared layout or deterministic digest binding | 432 | `c13f814fcf3ea1a2ec14e98fa38a323af32ee64230123093b385e2f7e460e23f` |
| `src/rationale_body.tex` | Distinct document view, shared layout or deterministic digest binding | 15083 | `e61558d4d16e9fd6140469ff6984487345f2ed906ffa058e0950e8b843d4d82e` |
| `tools/build_documents.py` | Document-only build, verification or evidence | 7023 | `bd5a5b3e80d4e2127d082b189ff5a98b71c41e738ed1fd5b4cee49fd50f0857a` |
| `tools/package_documents.py` | Document-only build, verification or evidence | 4849 | `7beb7d97e939ee41c52b4886e05b0c0c4ee8937b9b79e7d320f9adeb0ed07b34` |
| `tools/verify_documents.py` | Document-only build, verification or evidence | 10525 | `017b767c9dd4f6f2851c881839cbca203c4691e213ca6cd7620c0f4cce2f4dbb` |
