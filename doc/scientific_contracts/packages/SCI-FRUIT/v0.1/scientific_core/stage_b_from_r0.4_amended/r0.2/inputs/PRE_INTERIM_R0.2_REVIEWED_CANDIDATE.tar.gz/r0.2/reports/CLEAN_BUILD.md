# Clean document build - SCI-FRUIT v0.1/r0.2

Date: 2026-09-07. Build record: SCI-FRUIT-DOC-BUILD-R0.2-2026-09-07. Document verification only.

The builder copied exactly the source-inventory union plus deterministic digest bindings into an isolated source directory, used a separate empty output directory and a fresh Tectonic format cache, and compiled all three wrappers from the same locally verified resource bundle. No original document intermediates were inherited. Runtime/typeface resources are declared prerequisites, not scientific sources.

Source closure copied: **15 files**. All normal and clean builds contain **zero reported TeX warning/overfull/underfull/undefined-reference/missing-glyph diagnostics** under the verifier checks.

| View | Pages | Normal and clean PDF SHA-256 (identical bytes) |
| --- | ---: | --- |
| core | 22 | `71423b2a7434aa9491dc4ef89ee79a479684e1b47dc497e96c314dbd129d9876` |
| rationale | 9 | `eef8100feefd743fac2d4bcd6188ecd37f089c108bfdfdc290bcbbfccf6b6926` |
| ecs | 13 | `a85e50a9b5622e3dd67fdb6d8aa9085cc31bcf6bb4c521f58a09e6844e89fbba` |

All three complete PDF byte strings match the independently built copies; this is stronger than extracted-text parity for the declared local runtime/resources. No claim of bitwise parity with an unspecified different toolchain is made. Source hashes, metadata and local links are checked separately. See [build record](BUILD_RECORD.json) and [build recipe](../BUILD_RECIPE.md).
