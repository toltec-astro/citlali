# Requirement-to-evidence index

Sole normative authority: SCI-FRUIT-NORMATIVE-CORE v0.1/r0.2; canonical source-inventory SHA-256 `b02cff80eb4f1fb991214eb16d05a903f5dd3a363fe13461e83e5c96cf7411ed`. This is a derived navigation/evidence record, not independent science.

All procedures are prospective ECS EV-001--015. Every numerical result is `not_assessed`, blocked by the absent approved method-specific record and required upstream route; fixture/oracle/comparison are not instantiated.

| Requirement | Evidence procedure(s) | Exact observable summary | Result |
| --- | --- | --- | --- |
| SCI-FRUIT-REQ-001 | SCI-FRUIT-EV-001 | A/B/C decision binding | not_assessed |
| SCI-FRUIT-REQ-002 | SCI-FRUIT-EV-001, SCI-FRUIT-EV-004 | Typed object/domain inventory | not_assessed |
| SCI-FRUIT-REQ-003 | SCI-FRUIT-EV-002 | Three model stages and transformations | not_assessed |
| SCI-FRUIT-REQ-004 | SCI-FRUIT-EV-004 | Removal/rejoin compatibility | not_assessed |
| SCI-FRUIT-REQ-005 | SCI-FRUIT-EV-003, SCI-FRUIT-EV-006 | Complete path equation and counts | not_assessed |
| SCI-FRUIT-REQ-006 | SCI-FRUIT-EV-006, SCI-FRUIT-EV-010 | Linearity and derivative premises | not_assessed |
| SCI-FRUIT-REQ-007 | SCI-FRUIT-EV-001 | Route/grouping/input ancestry | not_assessed |
| SCI-FRUIT-REQ-008 | SCI-FRUIT-EV-005 | Eight support/influence roles | not_assessed |
| SCI-FRUIT-REQ-009 | SCI-FRUIT-EV-005, SCI-FRUIT-EV-006 | Occurrence and mode-origin propagation | not_assessed |
| SCI-FRUIT-REQ-010 | SCI-FRUIT-EV-007 | Rules versus realized generations | not_assessed |
| SCI-FRUIT-REQ-011 | SCI-FRUIT-EV-003, SCI-FRUIT-EV-007 | Ordered graph and seven categories | not_assessed |
| SCI-FRUIT-REQ-012 | SCI-FRUIT-EV-010 | RF-01/02 fixed numerical bindings | not_assessed |
| SCI-FRUIT-REQ-013 | SCI-FRUIT-EV-010 | RF-03--07 extent and rerun trace | not_assessed |
| SCI-FRUIT-REQ-014 | SCI-FRUIT-EV-011 | Pre-outcome law and four covariance blocks | not_assessed |
| SCI-FRUIT-REQ-015 | SCI-FRUIT-EV-002, SCI-FRUIT-EV-011 | Distinct uncertainty roles and bias premises | not_assessed |
| SCI-FRUIT-REQ-016 | SCI-FRUIT-EV-012 | Member meaning, centers and NOI action | not_assessed |
| SCI-FRUIT-REQ-017 | SCI-FRUIT-EV-008, SCI-FRUIT-EV-009 | Causal continuation/restart/retry state | not_assessed |
| SCI-FRUIT-REQ-018 | SCI-FRUIT-EV-009, SCI-FRUIT-EV-015 | Product roles and reached lifecycle | not_assessed |
| SCI-FRUIT-REQ-019 | SCI-FRUIT-EV-013 | Separate completion/stop/convergence | not_assessed |
| SCI-FRUIT-REQ-020 | SCI-FRUIT-EV-014 | Comparable immutable selector | not_assessed |
| SCI-FRUIT-REQ-021 | SCI-FRUIT-EV-006, SCI-FRUIT-EV-015 | Universal bundle and hard dependencies | not_assessed |
| SCI-FRUIT-REQ-022 | SCI-FRUIT-EV-001, SCI-FRUIT-EV-005, SCI-FRUIT-EV-012, SCI-FRUIT-EV-015 | Producer and child-decision ownership | not_assessed |
| SCI-FRUIT-REQ-023 | SCI-FRUIT-EV-001 | Complete method record and approval gate | not_assessed |
| SCI-FRUIT-REQ-024 | SCI-FRUIT-EV-006, SCI-FRUIT-EV-010, SCI-FRUIT-EV-011, SCI-FRUIT-EV-012, SCI-FRUIT-EV-015 | Predictions and typed claim ceilings | not_assessed |

The [machine index](evidence/INDEX_DATA.json) and [blank result record](evidence/CONFORMANCE_RESULT_TEMPLATE.json) preserve exact IDs. Canonical requirements are [full normative statements](src/common/requirements.tex), not these summaries.
