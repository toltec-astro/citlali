# Model-stage uncertainty crosswalk

Sole normative authority: SCI-FRUIT-NORMATIVE-CORE v0.1/r0.2; canonical source-inventory SHA-256 `b02cff80eb4f1fb991214eb16d05a903f5dd3a363fe13461e83e5c96cf7411ed`. This is a derived navigation/evidence record, not independent science.

Canonical location: [NOI/uncertainty and covariance sections](src/common/equations.tex), REQ-014--016, PRED-005/011/018. These role names parameterize `SCI-FRUIT/UNCERTAINTY/<role>`; they are separately addressable scientific targets, not a selected storage schema.

Every row must bind domain/axes, units (including product units for covariance/cross covariance), exact pre-outcome or explicitly narrower fixed-model conditioning, availability, cause, generation, omitted terms and reference/gauge/null-space consequences. Actual numerical values/laws remain unavailable. One container is permitted only if all distinctions remain lossless.

| Role | Required distinction |
| --- | --- |
| candidate-model/prior uncertainty | Candidate space and its exact prior/construction law; not accepted or applied covariance. |
| candidate-selection uncertainty | Selection dependence and its effect on the declared target; not hidden in one model covariance. |
| accepted-model covariance | Accepted axes/support/reference; not copied to applied axes. |
| acceptance-to-application transformation uncertainty | Exact transformation and dependence; deterministic versus uncertain facts explicit. |
| applied-model covariance | Applied-model axes/support used by the four-term fixed-linear result. |
| measured-parent/applied-model cross covariance | Both compatible cross orientations with exact dependence; no independence by ancestry omission. |
| external-prior uncertainty | External prior parent/law and its dependence, separate from stage-specific products. |
| model-mismatch and bias | Output shift versus exact expectation target; bias unavailable without estimand/reference/law. |
| measured-parent covariance | Exact parent population and covariance axes. |
| operator/state uncertainty | Consequential operator/state variation, separately approved method if random/nonlinear. |
| support/threshold selection | Declared selection/support target; no post-outcome conditioning shortcut. |
| stopping/terminal selection | Exact rule/population and induced uncertainty target. |
| empirical repeatability | Declared repeat population; not automatic analytic covariance/coverage. |
| NOI uncertainty | Exact member meaning, center, estimator, method/ensemble/state and parity. |

Accepted covariance/error reaches applied space only through the exact acceptance-to-application relation and dependence. This crosswalk introduces no delta-method approximation, independence premise, estimator or zero-uncertainty default.
