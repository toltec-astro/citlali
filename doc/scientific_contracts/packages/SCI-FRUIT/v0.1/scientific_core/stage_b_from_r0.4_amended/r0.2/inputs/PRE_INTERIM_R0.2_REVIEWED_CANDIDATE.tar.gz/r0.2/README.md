# SCI-FRUIT v0.1 - Stage B r0.2 owner-review packet

**Complete targeted revision, awaiting Grant Wilson's review. Stage B is not frozen. Stage A remains frozen.** Every numerical method and route remains `unavailable_pending_separate_owner_approval`; every numerical conformance result is `not_assessed`.

Download the [complete r0.2 owner-review tar.gz](SCI-FRUIT-v0.1-stage-b-r0.2-owner-review.tar.gz) and [SHA-256 sidecar](SCI-FRUIT-v0.1-stage-b-r0.2-owner-review.tar.gz.sha256). Start with the nine-page rationale; use the core for exact science and the ECS for prospective evidence procedures.

| Reading document | Role | Pages |
| --- | --- | ---: |
| [Normative scientific core](pdf/core.pdf) | Sole scientific authority: complete definitions, equations, 24 requirements, six assumptions and twenty predictions | 22 |
| [Scientific rationale](pdf/rationale.pdf) | Concise explanation importing selected canonical equations | 9 |
| [Engineering conformance specification](pdf/ecs.pdf) | Prospective candidate/evidence contracts, procedures, indexes and blank result contract | 13 |

The exact shared core identity is **SCI-FRUIT-NORMATIVE-CORE v0.1/r0.2**. Its SHA-256 is defined by the [canonical source inventory](identities/CORE_SOURCES.sha256) and appears identically on every cover. The rationale and ECS do not author broader science. The core exceeds its approximate twenty-page soft target by two pages to retain readable complete requirements/predictions.

## Requested deliverables

| No. | Product |
| ---: | --- |
| 1 | [Normative core PDF](pdf/core.pdf), [wrapper/body](src/core.tex), [canonical source identity](identities/CORE_SOURCES.sha256) |
| 2 | [Concise rationale PDF](pdf/rationale.pdf), [source](src/rationale_body.tex) |
| 3 | [Actual ECS PDF](pdf/ecs.pdf), [source](src/ecs_body.tex), [blank result record](evidence/CONFORMANCE_RESULT_TEMPLATE.json) |
| 4 | [Fixed numerical versus recomputed-rule response amendment](AMENDMENTS.md) |
| 5 | [General differentiable-response amendment](AMENDMENTS.md) |
| 6 | [Centered-perturbation versus full-product NOI boundary](AMENDMENTS.md) |
| 7 | [Pre-outcome conditioning amendment](AMENDMENTS.md) |
| 8 | [Model-error-transfer and bias amendment](AMENDMENTS.md) |
| 9 | [Model-stage uncertainty crosswalk](MODEL_UNCERTAINTY_CROSSWALK.md), [complete derived method record](METHOD_RECORD_TEMPLATE.md) |
| 10 | [Product-role and ordered-lifecycle table](PRODUCT_LIFECYCLE.md) |
| 11 | [Terminal-candidate comparability rule](TERMINAL_COMPARABILITY.md) |
| 12 | [Requirement-to-evidence index](REQUIREMENT_TO_EVIDENCE.md), [machine index](evidence/INDEX_DATA.json) |
| 13 | [Prediction-to-fixture index](PREDICTION_TO_FIXTURE.md) |
| 14 | [Exact source/authority identities](SOURCE_IDENTITIES.md), [owner ledger](OWNER_LEDGER.md), [decision log](DECISION_LOG.md), [build recipe](BUILD_RECIPE.md), [build record](reports/BUILD_RECORD.json) |
| 15 | [Semantic-change report](SEMANTIC_CHANGE_REPORT.md), [core/view parity](CORE_VIEW_PARITY.md), [clean build](reports/CLEAN_BUILD.md) |
| 16 | [PDF visual/metadata report](reports/PDF_VISUAL_METADATA.md), [page inspection](reports/PAGE_INSPECTION.json), [document verification](DOCUMENT_VERIFICATION.md) |
| 17 | [Proposed conditional owner disposition](PROPOSED_OWNER_DISPOSITION.md) - proposal only, no executed approval/freeze |

The [independent review](review/REVIEW_REPORT.md) closed with no findings in the third and final allowed substantive round. All 44 final pages were inspected; all three isolated clean builds reproduce their PDFs byte-for-byte. The [artifact manifest](ARTIFACT_MANIFEST.md) and [sidecar](ARTIFACT_MANIFEST.sha256) bind the complete delivery. Archive and manifest self-reference are excluded by explicit digest scopes.

`inputs/` contains exact preserved authority and historical material: all eleven admitted Stage A payloads, original amended Stage A archive and controls, the complete r0.1 delivery, and the exact r0.2 directive. The inherited r0.1 PDFs retain their original names under that historical path and are not r0.2 reading products. Archives inside inputs remain opaque and confer no broader scientific read permission. The separate in-progress snapshot created outside this directory is not included.

No numerical fixture, experiment, replay, reduction, implementation assessment, validation, performance, production or Unity activity occurred. Local document completion, consistency review and proposed owner disposition grant no numerical authority or downstream fitness. Nothing is pushed by the author.
