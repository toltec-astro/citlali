# Prediction-to-fixture index

Sole normative authority: SCI-FRUIT-NORMATIVE-CORE v0.1/r0.2; canonical source-inventory SHA-256 `b02cff80eb4f1fb991214eb16d05a903f5dd3a363fe13461e83e5c96cf7411ed`. This is a derived navigation/evidence record, not independent science.

All fixture identifiers are prospective designs with null numerical payloads. No numerical fixture, comparison, replay or experiment is performed. Every result is `not_assessed` under the absent approved exact method/route, fixture, independent oracle and preregistered comparison.

| Prediction / fixture | Design | Independent expected construction |
| --- | --- | --- |
| SCI-FRUIT-PRED-001 / SCI-FRUIT-FIX-001 | Zero applied operand; non-zero-preserving control | Substitute into composition under exact zero-preserving premises. |
| SCI-FRUIT-PRED-002 / SCI-FRUIT-FIX-002 | Identity residual and compatible equal removal/rejoin | Cancel compatible contributions; reject missing-space/gauge controls. |
| SCI-FRUIT-PRED-003 / SCI-FRUIT-FIX-003 | Complete linearity with equal model-path maps | Use exact operator equality to establish D=0 on declared domain. |
| SCI-FRUIT-PRED-004 / SCI-FRUIT-FIX-004 | Perfect applied reference, distinct accepted-stage control | Set residual to zero; retain rejoin meaning and unavailable-mode origin. |
| SCI-FRUIT-PRED-005 / SCI-FRUIT-FIX-005 | Applied error, transformed accepted error, missing bias law | Subtract reference outputs; require full estimand/law before expectation. |
| SCI-FRUIT-PRED-006 / SCI-FRUIT-FIX-006 | Numerically frozen versus prescribed PTC recomputation | Compare declared operators/rules; require induced-fixed-map proof for equivalence. |
| SCI-FRUIT-PRED-007 / SCI-FRUIT-FIX-007 | Permitted model-only and unavailable measured mode | Trace model/prior ancestry independently of occurrence support class. |
| SCI-FRUIT-PRED-008 / SCI-FRUIT-FIX-008 | Unequal support and incompatible reference/gauge | Check exact allowed restriction/composition or typed unavailability. |
| SCI-FRUIT-PRED-009 / SCI-FRUIT-FIX-009 | Differentiable fixed maps and complete-linear specialization | Independent chain rule; reduce to A,D; enclose prescribed reruns separately. |
| SCI-FRUIT-PRED-010 / SCI-FRUIT-FIX-010 | Branch/support/gauge/threshold query transition | Check comparison and derivative existence or separately typed transition. |
| SCI-FRUIT-PRED-011 / SCI-FRUIT-FIX-011 | Random versus fixed model; accepted-to-applied uncertainty | Expand joint covariance; retain both cross terms and transformed dependence. |
| SCI-FRUIT-PRED-012 / SCI-FRUIT-FIX-012 | Repeated shared parent/model lineage | Trace shared dependence; no independent-count uncertainty scaling. |
| SCI-FRUIT-PRED-013 / SCI-FRUIT-FIX-013 | Checkpoint after absolute index N and same future controls | Compare full causal state/results with uninterrupted continuation at N+1. |
| SCI-FRUIT-PRED-014 / SCI-FRUIT-FIX-014 | Restart, relearning, retry and early terminal failure | Compare rule/state/attempt lineage; require no fabricated later lifecycle. |
| SCI-FRUIT-PRED-015 / SCI-FRUIT-FIX-015 | Declared resource exhaustion without convergence premise | Separate exact limit accounting from convergence proposition. |
| SCI-FRUIT-PRED-016 / SCI-FRUIT-FIX-016 | Mixed comparable/mapped/incompatible terminal candidates | Apply exact selector conversion/comparison; retain all nine terminal fields. |
| SCI-FRUIT-PRED-017 / SCI-FRUIT-FIX-017 | Observation/coadd/joint grouping comparison | Require an exact commutation proof; shape agreement is insufficient. |
| SCI-FRUIT-PRED-018 / SCI-FRUIT-FIX-018 | Known-zero perturbations and full-affine/relearned members | Use A delta Y versus A Y+D m and exact centers; separate ensembles. |
| SCI-FRUIT-PRED-019 / SCI-FRUIT-FIX-019 | Missing/unapproved method or upstream authority | Gate remains unavailable; generic family/finite output never admits route. |
| SCI-FRUIT-PRED-020 / SCI-FRUIT-FIX-020 | Complete local parent with absent/failed/later child use | Compare immutable parent bytes/identity; child causes no new iteration. |

Each future fixture must bind immutable payload/digest, applicable assumptions, exact scientific domains/units/support/reference, independent oracle and preregistered comparison policy. No numerical tolerance, sample size, method or estimator is selected. See [canonical predictions](src/common/edge_cases.tex), [machine index](evidence/INDEX_DATA.json) and [ECS source](src/ecs_body.tex).
