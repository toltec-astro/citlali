# SCI-POINT v0.1 — Proposed Implementation-Blind Author Packet

Manifest identity: `SCI-POINT_AUTHOR_PACKET_MANIFEST v0.1/r0.1`

Status: complete, exclusive, and SHA-bound review candidate; not approved;
Stage B not launched

The future implementation-blind author may open this manifest and only the
nine exact objects below. No adjacent file, directory, package, repository,
history, link target, or external source is admitted.

## Exclusive Author Inputs

| # | Object | Role | SHA-256 |
| ---: | --- | --- | --- |
| 1 | `AUTHOR_SCOPE_BRIEF.md` | exact bounded assignment, products, claims, and exclusions | `b7d6f82e3ed3373a282a44271c3fd54fca0faeebd0a10666127584b9d7eda78c` |
| 2 | `AUTHOR_SUPERSESSION_COVER.md` | binding anti-reinvention rule and information firewall | `0cbc647af8d179070642cfad5c8c217b3c556331bafecb0e7ea57e8544da46dc` |
| 3 | `SCIENTIFIC_OWNER_DECISIONS_FOR_AUTHORSHIP.md` | closed ODQ-001 through ODQ-009 decisions and author freedom | `ec280b23a7c20cc5f438415b5ab8ad637dddaac8635ccdf85e6f5412984c09a5` |
| 4 | `AUTHOR_CONVENTIONS_AND_OWNERSHIP.md` | coordinate, fit, uncertainty, atomicity, diagnostic, and adjacent ownership conventions | `11f2184d91f42c8491ccf8e0f0d9e80c493137d777d17a552be1cca657842ebf` |
| 5 | `AUTHOR_WORKING_METHOD_CONSTRAINTS.md` | adopted working wheel, abstraction duties, and exclusions | `b15fa3841102bdc11db9b88e46b6a0af39f270afa9ad9dd0ccae69a833c81c67` |
| 6 | `AUTHOR_OPERATOR_AND_PRODUCT_TAXONOMY.md` | operator, product, external-role, and named-use taxonomy | `b92cbd97c126778ef043cee3bb2c688b74dbb1dac6e4cb1eca94b7c8ddda2b50` |
| 7 | `AUTHOR_PARENT_ROUTE_AND_CLAIM_MATRIX.md` | distinct eligible parent routes, FRUIT ancestry, and claim ceilings | `e57d3ff4fe86bd1f6a7a261f827762d1ec2b8f6e5894a920650450b8cdb9ecb7` |
| 8 | `AUTHOR_BOUNDARIES_AND_UNAVAILABLE_STATES.md` | required distinctions and typed unavailable states | `c76ad82644a8425c3ad02c8a1d5889bd85d543f65ab35a8e53968b26106df107` |
| 9 | `AUTHOR_PREDECESSOR_BOUNDARY_INPUTS.md` | compact sanitized predecessor ownership and convention inputs | `e4669f32a82f23c5396b1afb76fe8a65a7752e8ee45636aa11c9824d3b4fb690` |

Any byte change to an admitted object requires recomputed hashes, a successor
manifest/archive identity, and renewed exact-byte owner review. Scientific
family eligibility does not establish numerical route availability.

## Complete Prohibited-Input Firewall

The author must not inspect:

- `README.md`, `PRIOR_WORK.md`, `INTERNAL_DOSSIER.md`, recovery/adoption
  registers, source-identity records, raw scope directions, raw approval
  records, decision/change logs, Stage A crosswalks, or verification output;
- implementation, headers, configuration, defaults, schemas, registries,
  tests, audits, repairs, validation, reductions, generated products, logs,
  baselines, accepted runs, performance evidence, or Unity material;
- full predecessor or adjacent scientific packages;
- unlisted repository files, branches, histories, web sources, external
  papers, or model memory as substitute authority; or
- any member of the `.tar.gz` archive not named in this manifest. The archive
  is constructed to contain only this manifest, its digest sidecar, and the
  nine admitted objects.

If the packet is insufficient, the author returns one precise scientific
question and stops. It may not inspect prohibited material or invent a
scientific default.

## Author Controls And Dispatch State

The author must preserve the mature compatibility estimator, exact route
identity, per-array atomicity, measured-displacement boundary, external
aggregate/correction ownership, honest uncertainty and covariance states,
bounded amplitude/effective-shape/QC claims, and separate named-use policy
ownership. Exact profile mechanics are author-assigned for final owner review.

This manifest and archive do not launch Stage B. Dispatch requires explicit
scientific-owner approval of this exact manifest and all admitted object
hashes, followed by an explicit fresh-task launch. No implementation,
validation, achieved pointing performance, readiness, production, or Unity
claim is authorized.
