# SCI-POINT v0.1 Author Working-Method Constraints

Identity: `SCI-POINT_WORKING_METHOD_CONSTRAINTS v0.1/r0.1`

Status: sanitized author input candidate

## Adopt Without Reinvention

- one known, isolated, bright Pointing source approximately centered in one
  observation-local map for each requested TolTEC array;
- the zero-background six-parameter elliptical Gaussian: amplitude, two-
  coordinate centroid, two fitted widths, and angle;
- a weighted fit over a bounded region with declared expected center,
  weighted-peak initialization, central search, global fallback, and parameter
  constraints;
- authoritative per-array fit results containing centroid, amplitude, widths,
  angle, available marginal formal errors, and honest state;
- AltAz tangent-plane source displacements in arcseconds;
- established dynamic-range and formal-standardization diagnostics under
  truthful non-significance labels; and
- shared numerical fitter reuse with Beammap as an engineering possibility
  that does not merge POINT and SCI-BEAM scientific ownership.

## Abstract Scientifically

- Replace hidden configuration/default behavior with explicit requested,
  effective, and realized state.
- Identify exact parent route and complete FRUIT ancestry; never infer either
  from filenames or directory placement.
- State weight/covariance use, support, non-finite treatment, constraint
  realization, degeneracy, uncertainty meaning, and parent response.
- Preserve current scientific behavior while allowing implementation-neutral
  mathematics and terminology.

## Explicitly Exclude

- a new profile family, free-background extension, blind detection, deblending,
  catalog construction, or blank-field faint-source fitting;
- per-detector Beammap fitting, intrinsic/effective detector PSF authority,
  sensitivity, or APT production;
- OOF optical inference;
- automatic MAP/JINC/FLT route selection, substitution, or fallback;
- coadd fitting or intermediate FRUIT iteration fitting;
- POINT-owned cross-array aggregation, correction sign/composition,
  correction-record selection/publication, or correction application;
- assuming missing covariance is zero, diagonal, or independence; and
- universal flux, intrinsic beam, statistical significance, unique QC cause,
  implementation conformity, validation, performance, readiness, or
  production claims.

## Truthful Diagnostic Identities

- legacy `sig2noise`: fitted amplitude divided by full-map RMS; retained as a
  dynamic-range diagnostic, not statistical significance;
- `peak_over_full_map_rms`: truthful name for the same descriptive ratio; and
- `fit_sig2noise`: fitted amplitude divided by its formal fitted-amplitude
  error; formal standardization only, not empirical S/N or detection
  probability.
