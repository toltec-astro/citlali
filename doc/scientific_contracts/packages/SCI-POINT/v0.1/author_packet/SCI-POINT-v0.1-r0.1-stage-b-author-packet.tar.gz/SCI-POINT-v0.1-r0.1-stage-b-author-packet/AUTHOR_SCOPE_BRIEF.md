# SCI-POINT v0.1 — Implementation-Blind Author Scope Brief

Identity: `SCI-POINT_AUTHOR_SCOPE v0.1/r0.1`

Status: closed scientific-content candidate; exact packet approval and Stage B
launch pending

## Assignment

Author one shared SCI-POINT v0.1 scientific core and two views:

1. a scientist-readable rationale; and
2. an engineering-conformance specification importing the same core.

SCI-POINT fits one known, isolated, bright Pointing source on one exact
observation-local per-array map product. Its primary scientific result is the
measured source displacement in the declared AltAz tangent basis. It also
publishes the complete six-parameter fit, formal uncertainty state, support,
method, parent, and use-specific eligibility facts.

The author shall formalize the approved working method rather than invent a
new source fitter.

## Exact Scientific Operation

The base method is
`POINT-FIT/ELLIPTICAL-GAUSSIAN-COMPATIBILITY@1`, the established
zero-background six-parameter elliptical Gaussian with:

- fitted amplitude;
- two continuous centroid coordinates;
- two fitted widths; and
- fitted orientation angle.

The author shall state the model, parameter ordering, width convention,
orientation gauge and degeneracies, map weighting or covariance use, support,
initialization/search, constraints, failure behavior, response interpretation,
and formal uncertainty meaning completely. No additional profile family is
part of base v0.1.

## Inputs

Every requested fit binds:

- observation and array identity;
- exact observation-local MAP, JINC, FLT-FIXED, or FLT-MATCHED parent family,
  product, method, version, and generation;
- complete terminal FRUIT ancestry when FRUIT produced the terminal map;
- parent estimand, signal unit, calibration, normalization, WCS, grid, AltAz
  tangent basis, pixel metric, orientation, handedness, support, validity,
  missing/non-finite policy, response, covariance/uncertainty state,
  null-space, and provenance;
- known source identity, expected position/search center, assumed morphology,
  and available position uncertainty; and
- requested fit method and all requested configuration states.

MAP, JINC, FLT-FIXED, and FLT-MATCHED are four eligible but non-equivalent
routes. POINT may not choose, substitute, equate, or fall back among them.
FRUIT is ancestry on one of those terminal map types, not a fifth parent.
Coadds and intermediate FRUIT iterations are outside base v0.1.

## Search, Support, And Constraint State

Preserve the established configurable:

- expected center and central search domain;
- weighted-peak initialization;
- global-search fallback;
- bounded fit domain; and
- amplitude, fitted-width, and orientation-angle constraints.

Requested, effective, and realized values or named states are distinct method
identity. Every realized fallback is reported. Numeric sentinels resolve to
explicit named effective states. The contract shall neither freeze one
universal numerical configuration nor authorize a new algorithm or silent
replacement.

## Products And Claims

Each requested observation-array-parent-method fit is independently atomic
and publishes one complete, diagnostic-only, or unavailable result with the
affected use or claim and reason.

The complete numerical fit contains:

- measured two-component tangent-plane displacement in arcseconds;
- fitted amplitude in the exact parent product's unit and response;
- two effective fitted widths and orientation under the exact processed-map
  response;
- available marginal formal parameter errors and honest joint-covariance
  availability;
- fit support, constraints, requested/effective/realized state, parent and
  method identity; and
- the declared legacy dynamic-range and formal-standardization diagnostics
  where those quantities are produced.

Centroid displacement is the primary pointing measurement. Fitted centroid,
amplitude, widths, angle, and fit state are also telescope/observing-condition
quality-control metrics. Amplitude is not automatically universal flux.
Effective fitted shape is not automatically an intrinsic telescope beam,
detector PSF, or SCI-BEAM result. The metrics alone do not identify a unique
physical cause for a deviation.

## Uncertainty

Publish the established marginal formal parameter errors when available and
state their method, assumptions, domain, conditioning, and limitations. Full
joint parameter covariance may be unavailable. Absence of joint covariance is
not zero, diagonal covariance, or evidence of independence and does not by
itself invalidate the fit.

Later joint-covariance, astrometric, empirical-repeatability, or NOI
uncertainty estimates are separately versioned companions to the immutable
POINT result. They do not rewrite the original uncertainty claim.

## Named Uses And Policy Ownership

Keep four named-use policies distinct:

1. POINT owns per-array fit-result completeness.
2. The pointing-support producer owns displacement admission for correction
   construction.
3. The named telescope/observing QC process owns parameter admission,
   references, thresholds, comparisons, aggregation, and actions.
4. CAL or TolProj owns amplitude admission for photometric transfer.

The same result may pass one use, fail another, and be diagnostic-only for a
third. Diagnostic-only is use-specific, not a universal bad-result flag. VAL
registers/evaluates exact profiles and authors none of them. The author may
propose collision-free identifiers and mechanics for final owner review. No
whole-observation or cross-array aggregate profile belongs to POINT v0.1.

## Downstream Boundary

SCI-POINT ends with authoritative per-array measurements. It does not form a
cross-array aggregate and does not convert measured displacement into an
applied correction. The named pointing-support producer owns any aggregation,
member/weight/covariance/failure policy, measurement-to-correction sign,
telescope user/paddle-offset composition, record selection, native support,
and correction-record publication. AST owns conforming application.

Failure of one array does not erase sibling results. POINT never imputes a
missing array or reports a whole-observation success state. A downstream
producer that admits a partial array set owns and records that exact policy and
membership.

## Non-Goals And Claim Ceiling

SCI-POINT v0.1 does not perform blind detection, deblending, cataloging,
blank-field faint-source fitting, per-detector Beammap inference, OOF optical
inference, mapmaking, filtering, FRUIT recurrence, calibration, empirical
uncertainty inference, correction selection, interpolation, or application.

The contract establishes scientific meaning only. It shall not claim
implementation conformity, observational validation, uncertainty coverage,
achieved response, pointing accuracy, performance, readiness, production
suitability, or Unity state.

## Required Stage B Deliverables

The author shall return:

- one shared normative scientific core;
- scientist-readable scientific rationale and engineering-conformance views;
- stable requirement IDs and falsifiable prediction IDs with complete
  traceability;
- explicit typed unavailable states and edge cases;
- draft exact named-use profile identifiers/mechanics under the approved owner
  boundaries; and
- source/build manifests and draft PDFs.

If this exclusive packet is scientifically insufficient, the author shall
return one precise question and stop. The author may not inspect a prohibited
source, infer an implementation default, or broaden the package.
