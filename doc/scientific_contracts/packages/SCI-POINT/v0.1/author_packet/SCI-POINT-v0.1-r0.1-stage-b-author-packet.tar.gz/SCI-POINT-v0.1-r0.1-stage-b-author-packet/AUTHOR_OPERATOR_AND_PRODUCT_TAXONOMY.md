# SCI-POINT v0.1 Author Operator And Product Taxonomy

Identity: `SCI-POINT_AUTHOR_TAXONOMY v0.1/r0.1`

Status: sanitized taxonomy candidate; exact profile identifiers author-assigned

## Operator

### `POINT-FIT/ELLIPTICAL-GAUSSIAN-COMPATIBILITY@1`

Fits the approved known-source model on one exact observation-local per-array
map parent. Complete identity includes parent family/product/version/
generation, observation, array, WCS/grid/frame, terminal FRUIT ancestry when
applicable, source and expected-center relation, model, requested/effective/
realized search and support, weight/covariance use, constraints, response,
calibration, estimator version, and fit state.

Changing a scientifically consequential element creates a different method or
an explicitly compatible successor. “Gaussian fit,” `raw`, or `filtered` is
not a complete identity.

## Required Per-Array Product Roles

| Product role | Meaning | Claim ceiling |
| --- | --- | --- |
| `POINT-FIT-RESULT` | complete six-parameter fit, status, support, method, parent, available marginal formal errors, and covariance availability | not an applied correction, intrinsic beam, or source catalog |
| `POINT-DISPLACEMENT-MEASUREMENT` | fitted two-component AltAz tangent-plane source displacement | not absolute celestial position or correction vector |
| `POINT-AMPLITUDE-DIAGNOSTIC` | required fitted amplitude and QC metric in exact parent unit/calibration/response; eligible for separately authorized CAL/TolProj use | not universal source flux or standalone absolute calibration |
| `POINT-EFFECTIVE-SHAPE-DIAGNOSTIC` | required fitted widths/angle and QC metrics under exact parent response | not intrinsic telescope beam, detector PSF, SCI-BEAM product, or unique causal diagnosis |
| `POINT-FIT-QUALITY-CONTROL-METRICS` | centroid, amplitude, effective shape, uncertainty/constraint/support, and honest fit state for telescope/observing QC | not an automatic threshold/action or causal model |
| `POINT-LEGACY-DYNAMIC-RANGE` | amplitude/full-map RMS | not statistical significance |
| `POINT-FORMAL-STANDARDIZATION` | amplitude/formal amplitude error | not empirical S/N or detection probability |
| unavailable result | typed unavailable role, affected claim/use, and reason | not numerical zero or successful fit |

Every requested observation-array-parent-method fit has independent complete,
diagnostic-only, or unavailable state. Physical co-location in one table or
file does not merge atomicity.

## External Roles

- Cross-array aggregation and correction-record construction are external
  pointing-support-producer operations.
- Correction application is an AST operation.
- Photometric transfer is a CAL/TolProj operation.
- Joint-covariance, astrometric, empirical-repeatability, and NOI uncertainty
  companions are separately versioned external or successor products.

## Named-Use Policy Roles

The author shall define collision-free draft identities and mechanics for:

1. POINT per-array fit completeness;
2. pointing-support displacement admission;
3. telescope/observing QC parameter admission and actions; and
4. CAL/TolProj photometric-transfer amplitude admission.

The author must preserve the owner of each policy, use-specific outcomes,
diagnostic-only semantics, and VAL's registry/evaluator-only role. No universal
eligibility flag or POINT aggregate profile is permitted.
