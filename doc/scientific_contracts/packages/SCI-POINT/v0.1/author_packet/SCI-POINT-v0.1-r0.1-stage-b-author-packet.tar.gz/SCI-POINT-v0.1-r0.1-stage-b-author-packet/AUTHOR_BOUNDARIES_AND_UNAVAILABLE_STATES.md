# SCI-POINT v0.1 Author Boundaries And Unavailable States

Identity: `SCI-POINT_BOUNDARIES_UNAVAILABLE v0.1/r0.1`

Status: sanitized author input candidate

## Required Boundary Distinctions

- Targeted Pointing inference is not blind detection or catalog fitting.
- Per-array POINT measurements are not a cross-array aggregate or telescope
  correction.
- Measured displacement is not correction sign/composition/application.
- MAP, JINC, FLT-FIXED, and FLT-MATCHED are distinct routes.
- FRUIT ancestry is not a separate map type.
- Parent WCS/response/support/covariance is not POINT-owned.
- Marginal formal errors are not joint covariance, astrometric uncertainty,
  empirical repeatability, calibration uncertainty, or significance.
- Effective fitted width is a useful QC metric but not automatically an
  intrinsic beam or SCI-BEAM product.
- A QC metric is not an automatic threshold/action or unique causal diagnosis.
- Named-use eligibility is not one universal good/bad flag.
- Per-array scientific atomicity is not file/table atomicity.

## Typed Unavailable States

| Identity | Unavailable quantity or claim | Release condition or disposition |
| --- | --- | --- |
| `SCI-POINT-UNAV-001` | POINT-owned cross-array aggregate | outside base v0.1; future successor decision required |
| `SCI-POINT-UNAV-002` | POINT-owned correction candidate or applied correction | outside base v0.1; pointing-support producer and AST retain ownership |
| `SCI-POINT-UNAV-003` | numerical MAP/JINC/FLT POINT route | exact predecessor authority, numerical product, required state, and POINT compatibility binding |
| `SCI-POINT-UNAV-004` | numerical compatibility fit beyond scientific method selection | complete Stage B method/support/constraint binding plus exact numerical parent |
| `SCI-POINT-UNAV-005` | POINT whole-observation success from partial arrays | outside base v0.1; downstream producer owns any partial-set admission |
| `SCI-POINT-UNAV-006` | full joint covariance or uncertainty calibration/coverage | separately authorized representation and evidence; fit may remain valid without it |
| `SCI-POINT-UNAV-007` | absolute flux or calibration accuracy | exact CAL/TolProj authorization and evidence; never POINT alone |
| `SCI-POINT-UNAV-008` | intrinsic beam inference from Pointing width | separate authorized method; SCI-BEAM boundary preserved |
| `SCI-POINT-UNAV-009` | statistical significance or detection probability | complete probabilistic method and validation; neither legacy nor formal ratio is enough |
| `SCI-POINT-UNAV-010` | applied correction for another observation | exact producer selection and AST application authority |
| `SCI-POINT-UNAV-011` | OOF or blank-field source result | future separate package authority |
| `SCI-POINT-UNAV-012` | coadd or intermediate-FRUIT POINT parent | outside base v0.1 |
| `SCI-POINT-UNAV-013` | universal cross-use eligibility or POINT aggregate profile | prohibited; named-use owners define separate policies and VAL only evaluates |

Unavailable means the named quantity or claim is not established. It does not
require discarding an honest per-array fit or prohibit a later versioned
companion or successor product.
