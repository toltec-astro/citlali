# SCI-POINT v0.1 Author Parent Route And Claim Matrix

Identity: `SCI-POINT_PARENT_ROUTE_MATRIX v0.1/r0.1`

Status: scientifically eligible families; numerical availability not established

| Parent family | POINT interpretation | Required bound state | Claim boundary |
| --- | --- | --- | --- |
| observation-local SCI-MAP per-array map | displacement/amplitude/effective shape under ordinary MAP response | exact product, estimand, unit, WCS, support, validity, response, covariance, calibration, generation | claims remain conditional on ordinary MAP state |
| observation-local SCI-JINC per-array map | displacement/amplitude/effective shape under signed JINC response | exact normalization, coefficient, support, response/covariance, generation, unit | distinct route; never silently equivalent to MAP |
| observation-local SCI-FLT-FIXED product | fit after declared fixed convolution | exact parent plus filter operator/kernel, normalization, response, edge/support, covariance state | transformed-route fit; no automatic equivalence to unfiltered fit |
| observation-local SCI-FLT-MATCHED product | centroid and amplitude relation on a matched-template amplitude map | exact template, complete support, output unit, response, covariance option, phase/origin | fitting the matched-filtered peak is a distinct method |
| NOI standardized-signal companion | search/QC diagnostic scale only | exact signal parent and NOI uncertainty product | not a POINT amplitude/displacement parent in base v0.1 |

## FRUIT Ancestry

A terminal product created through FRUIT is consumed under its exact MAP,
JINC, FLT-FIXED, or FLT-MATCHED type and binds complete FRUIT method, terminal
iteration, generation, response, support, uncertainty, and lineage. FRUIT is
not a fifth route; intermediate iterations are excluded.

## Route Rule

For any requested route, POINT claims only fitted quantities under the exact
parent's response, support, frame, unit, calibration, and uncertainty state.
POINT never automatically chooses, substitutes, equates, or falls back among
routes. Unavailability of one eligible route does not authorize another.

Coadd parents are outside base v0.1.
