# SCI-JINC To SCI-POINT Boundary

Identity: `SCI-JINC_TO_SCI-POINT v0.1/r0.2`

The boundary binds exact observation and array, immutable JINC product,
signed estimand, normalization and coefficient method, method/version/
generation, unit/calibration, WCS/grid/frame/tangent basis, support/validity,
missing/non-finite policy, response, covariance/uncertainty,
null/additive-reference state, phase/origin, lifecycle, and provenance.

It also binds source morphology -> signed/normalized JINC response -> expected
processed-map profile -> Gaussian compatibility, including response center,
model mismatch, expected centroid bias or typed unavailability, fit-domain
relation, and displacement-claim status.

Current numerical state:
`unavailable_pending_method_and_route_binding`. JINC is not silently
equivalent to MAP and is not an automatic substitute or fallback.
