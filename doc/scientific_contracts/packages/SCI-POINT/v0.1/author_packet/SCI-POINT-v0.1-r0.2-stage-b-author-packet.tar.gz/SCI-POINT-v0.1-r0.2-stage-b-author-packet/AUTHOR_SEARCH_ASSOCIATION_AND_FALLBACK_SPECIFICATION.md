# SCI-POINT Search, Association, Fallback, And Sentinel Specification

Identity: `SCI-POINT_SEARCH_ASSOCIATION_ENVELOPE v0.1/r0.2`

The known-source method distinguishes authoritative expected position,
requested search center, effective search center, selected peak/seed, fitted
centroid, and final source-association state.

The mature procedure's central-search domain, peak score and weight, candidate
population, interpolation, tie rule, parameter initialization, fallback
trigger/domain, fit-support motion, constrained resolution, multiple-minimum
rule, termination, retry, and sentinel mapping remain unavailable pending the
compatibility-method record. Requested, effective, resolved, applied, and
realized search/fallback states must remain distinct when that record becomes
available.

Global fallback is an internal branch of a known-source method, not blind
detection. It produces a candidate seed, not source identity. Source
association must be separately established over a declared association domain
using an exact method. Its state is one of `established`, `unavailable`, or
`failed`. A global maximum, finite fit, dynamic range, or formal
standardization cannot establish association.

Source-attributed displacement and amplitude require `established`
association. A numerical fit to an unassociated feature may remain a fit
diagnostic but cannot inherit the intended source identity.
