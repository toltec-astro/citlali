# SCI-FLT-MATCHED To SCI-POINT Boundary

Identity: `SCI-FLT-MATCHED_TO_SCI-POINT v0.1/r0.2`

The boundary binds exact observation and array, immutable matched product and
its parent, template and covariance/noise selector, complete support,
normalization, method/version/generation, output unit/calibration,
WCS/grid/frame/tangent basis, validity/edge state, missing/non-finite policy,
response, covariance option, null/additive-reference state, phase/origin,
lifecycle, and provenance.

It also binds source morphology -> parent/template/noise/phase response ->
expected matched amplitude-map profile -> Gaussian compatibility, including
response center, model mismatch, expected centroid bias or typed
unavailability, fit-domain relation, and displacement-claim status.

Current numerical state:
`unavailable_pending_method_and_route_binding`. A matched-filtered peak is a
distinct route and provides no automatic substitute or fallback.
