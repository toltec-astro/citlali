# SCI-POINT Response And Bias States

Identity: `SCI-POINT_RESPONSE_BIAS v0.1/r0.2`

POINT is nonlinear when search, fallback, support, or active constraints depend
on data. Three authorities remain distinct:

1. `fixed_branch_local_response`: conditional on one exact seed/fallback
   branch, fit support, fit-weight state, and active-constraint set;
2. `full_procedure_response`: reruns central search, peak initialization,
   fallback, fit-domain resolution, constraint activation, and optimization
   under perturbation; and
3. `observational_pointing_bias_accuracy`: separately established empirical
   behavior.

Parent-map response is input state, not automatically the response of the fit
procedure. A local Jacobian is not full-procedure response. Until separately
authorized, both POINT response roles and observational bias/accuracy are
typed unavailable; their absence does not authorize zero response error or
zero centroid bias.
