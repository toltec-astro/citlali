# SCI-FLT-FIXED To SCI-POINT Boundary

Identity: `SCI-FLT-FIXED_TO_SCI-POINT v0.1/r0.2`

The boundary binds exact observation and array, immutable filtered product and
its MAP/JINC parent, filter operator/kernel and version, normalization,
method/generation, unit/calibration, WCS/grid/frame/tangent basis,
support/validity, edge state, missing/non-finite policy, response,
covariance/uncertainty, null/additive-reference state, phase/origin,
lifecycle, and provenance.

It also binds source morphology -> parent response -> fixed filter response ->
expected processed-map profile -> Gaussian compatibility, including response
center, model mismatch, expected centroid bias or typed unavailability,
fit-domain relation, and displacement-claim status.

Current numerical state:
`unavailable_pending_method_and_route_binding`. The filtered route is not
silently equivalent to its unfiltered parent and provides no automatic
substitute or fallback.
