# SCI-POINT Required Falsifiable Predictions For Stage B

Identity: `SCI-POINT_AUTHOR_PREDICTIONS v0.1/r0.2`

These are draft authorship obligations, not Stage B normative IDs and not
validation claims. Stage B shall assign stable prediction IDs and trace each
to exact requirements and products.

| Draft ID | Required falsifiable consequence |
| --- | --- |
| `POINT-AUTHOR-PRED-001` | An exact noiseless matching Gaussian recovers the authorized parameters subject to the exact compatibility method. |
| `POINT-AUTHOR-PRED-002` | Multiplying an admitted parent map and compatible amplitude unit by an authorized scale produces the method-declared amplitude scaling without moving the source reference. |
| `POINT-AUTHOR-PRED-003` | Positive displacement follows fitted centroid minus expected source position in the declared basis; correction sign remains downstream. |
| `POINT-AUTHOR-PRED-004` | Changing only the search center may change branch/seed but never measurement zero. |
| `POINT-AUTHOR-PRED-005` | WCS handedness or tangent-basis changes transform components by the exact boundary, independent of memory/display order. |
| `POINT-AUTHOR-PRED-006` | Central-search and global-fallback branches are distinguishable in realized state. |
| `POINT-AUTHOR-PRED-007` | An exact score tie follows the future method's deterministic tie rule. |
| `POINT-AUTHOR-PRED-008` | A wrong global peak cannot yield source-attributed displacement without established association. |
| `POINT-AUTHOR-PRED-009` | Exchanging principal axes with the corresponding angle transformation leaves the Gaussian invariant. |
| `POINT-AUTHOR-PRED-010` | Exact circularity makes orientation undefined by model symmetry. |
| `POINT-AUTHOR-PRED-011` | Active amplitude, width, or angle constraints are reported and components become bound-censored where applicable. |
| `POINT-AUTHOR-PRED-012` | An unmodeled constant or gradient can bias fit parameters and is visible in residual/additive-reference state rather than silently fitted. |
| `POINT-AUTHOR-PRED-013` | Missing or non-finite admitted support follows exact method failure/unavailability rules. |
| `POINT-AUTHOR-PRED-014` | Reliability weights cannot be interpreted as inverse covariance without explicit authority. |
| `POINT-AUTHOR-PRED-015` | Rank deficiency, active bounds, non-positive curvature, or unresolved angle degeneracy can leave fitted values while making formal errors unavailable. |
| `POINT-AUTHOR-PRED-016` | Route-specific MAP/JINC/FLT response mismatch changes compatibility/bias state and cannot be erased by common Gaussian naming. |
| `POINT-AUTHOR-PRED-017` | Parent-response asymmetry may produce typed centroid-bias state rather than assumed zero bias. |
| `POINT-AUTHOR-PRED-018` | A terminal FRUIT product retains exact terminal route and ancestry; an intermediate iteration is rejected. |
| `POINT-AUTHOR-PRED-019` | Failure of one array preserves conforming sibling products and produces no POINT whole-observation success. |
| `POINT-AUTHOR-PRED-020` | No input produces a POINT-owned cross-array aggregate or telescope correction. |
| `POINT-AUTHOR-PRED-021` | The dynamic-range ratio follows the exact RMS authority and becomes unavailable for a zero/unavailable denominator. |
| `POINT-AUTHOR-PRED-022` | Formal standardization is unavailable without the exact formal-error method and never becomes statistical significance by naming. |
| `POINT-AUTHOR-PRED-023` | One immutable fit may receive different use-specific dispositions, including `diagnostic_only`, without changing producer lifecycle. |
| `POINT-AUTHOR-PRED-024` | Missing named-use profile, source authority, coordinate boundary, or source association yields the corresponding typed unavailable decision. |
| `POINT-AUTHOR-PRED-025` | Fixed-branch response cannot be reported as full-procedure response, and neither establishes empirical pointing accuracy. |
