# SCI-POINT Producer Lifecycle, Identifiability, And Named Uses

Identity: `SCI-POINT_TYPED_STATE_AXES v0.1/r0.2`

## Producer/Lifecycle Axis

Allowed roles are `not_requested`, `requested`, `effective`, `unavailable`,
`resolved`, `fit_attempted`, `fit_realized`,
`complete_publication_candidate`, `publication_decided`, `published`,
`failed`, `not_produced`, and `superseded`. A failed attempt is distinct from
a scientifically unavailable method or route.

## Component-Identifiability Axis

Every required parameter role carries exactly one of
`available_identifiable`, `available_bound_censored`, `weakly_identified`,
`undefined_by_model_symmetry`, `unavailable`, or `failed`.

## Named-Use Axis

Each named-use owner returns exactly one of `eligible`, `ineligible`,
`decision_unavailable`, `diagnostic_only`, `not_requested`, or `inapplicable`,
with exact profile identity, source facts, reasons, and evaluation provenance.
`diagnostic_only` never describes producer completion.

One complete immutable fit may be eligible for telescope-health diagnosis,
diagnostic-only for pointing correction, ineligible for photometric transfer,
and decision-unavailable for a use whose profile is unbound. No disposition
automatically propagates across uses.

Each array is scientifically atomic. Failure of one does not erase siblings;
POINT does not synthesize missing arrays or publish observation-wide success.
