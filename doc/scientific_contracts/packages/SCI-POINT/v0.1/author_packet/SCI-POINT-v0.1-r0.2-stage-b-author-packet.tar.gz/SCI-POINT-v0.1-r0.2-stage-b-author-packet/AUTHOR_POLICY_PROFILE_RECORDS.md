# SCI-POINT Draft Named-Use Policy/Profile Records

Identity: `SCI-POINT_POLICY_PROFILE_DRAFTS v0.1/r0.2`

Status: collision-free draft mechanics for final owner review; not approved

| Draft profile identity | Policy owner | Use | Current evaluability |
| --- | --- | --- | --- |
| `VAL-PROFILE/SCI-POINT/FIT-COMPLETENESS/PER-ARRAY@draft-r0.2` | POINT | decide whether one per-array fit bundle is a complete publication candidate | decision unavailable while numerical method is unavailable |
| `VAL-PROFILE/POINTING-SUPPORT/POINT-DISPLACEMENT-ADMISSION@draft-r0.2` | pointing-support producer | admit one measured displacement to correction construction | decision unavailable without displacement and owner policy |
| `VAL-PROFILE/TELESCOPE-QC/POINT-PARAMETER-ADMISSION@draft-r0.2` | named telescope-QC process | admit exact POINT metrics to QC comparison/action | decision unavailable without metrics and owner policy |
| `VAL-PROFILE/CAL-TOLPROJ/POINT-AMPLITUDE-TRANSFER@draft-r0.2` | CAL/TolProj | admit exact fitted amplitude for photometric transfer | decision unavailable without amplitude and owner policy |

Each record binds profile version/digest, policy owner, named use, exact source
facts and source bindings, applicability, eligibility rules, required
unavailable-state behavior, result disposition/reasons, evaluation identity,
and provenance. Independent dispositions are `eligible`, `ineligible`,
`decision_unavailable`, `diagnostic_only`, `not_requested`, or `inapplicable`.

VAL owns registry identity, source binding, evaluation, and result provenance.
VAL does not author any policy, combine uses into a universal flag, or let one
profile rescue a datum excluded by another policy for the same declared use.
No aggregate or universal eligibility profile enters base v0.1.
