# SCI-POINT Stage A `r0.1` To `r0.2` Semantic-Change Report

Identity: `SCI-POINT_STAGE_A_SEMANTIC_CHANGE v0.1/r0.2`

## Preserved

The repair preserves the known isolated bright source; independent per-array
fits; no POINT aggregate/correction; downstream pointing-support and AST
ownership; four distinct observation-local parent classes; terminal FRUIT
ancestry; coadd/intermediate exclusion; zero-background six-role Gaussian
family; configurable search/fallback/domain/constraints; per-array atomicity;
fit/QC component roles and claim ceilings; non-significance diagnostics;
separate adjacent ownership; implementation blindness; and all nonclaims.

## Repaired

- source reference, map origin, search center, and centroid are separate;
- displacement is fitted centroid minus authoritative expected position in an
  exact AST-bound AltAz tangent basis;
- the symbolic Gaussian uses an invariant positive-definite shape matrix while
  legacy numerical width/angle conventions remain unavailable;
- numerical objective/weights/search/solution and marginal formal errors have
  separate missing authorities and dependency scopes;
- source association is distinct from global fallback;
- route-specific response/model compatibility and terminal-FRUIT envelopes
  are explicit;
- zero-background residuals, component identifiability, local/full response,
  uncertainty budget, diagnostics, and downstream envelopes are typed; and
- `diagnostic_only` moved from producer state to named-use disposition.

## Availability Consequence

`POINT-COMPATIBILITY-METHOD v0.1` and
`POINT-FORMAL-ERROR-METHOD v0.1` are both
`unavailable_pending_separate_owner_approval`. The first blocks every numerical
fit and fit-derived product. Once it is approved, the second alone blocks
formal errors, joint covariance unless separately authorized, formal
standardization, and formal-uncertainty-dependent uses. No implementation
behavior closes either authority.

No numerical route, implementation conformity, response/covariance fidelity,
uncertainty coverage, pointing accuracy, observational validation, readiness,
production suitability, production authorization, or Unity activity is
claimed. Stage B has not been launched.
